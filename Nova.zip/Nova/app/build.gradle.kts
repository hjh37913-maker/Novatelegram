plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "app.nova"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.nova.client"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        // Optional defaults (can also be entered inside the app on first launch)
        buildConfigField("int", "TG_API_ID", (System.getenv("TG_API_ID") ?: "0").ifBlank { "0" })
        buildConfigField("String", "TG_API_HASH", "\"" + (System.getenv("TG_API_HASH") ?: "") + "\"")
    }

    signingConfigs {
        create("nova") {
            storeFile = file("../nova.keystore")
            storePassword = "novapass123"
            keyAlias = "nova"
            keyPassword = "novapass123"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("nova") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("nova")
        }
    }

    lint { abortOnError = false; checkReleaseBuilds = false }

    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.09.03")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.fragment:fragment-ktx:1.8.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-gif:2.7.0")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    // Prebuilt TDLib (official Telegram library) for Android
    implementation("com.github.fazilus:tdlib-android:1.8.61")
}
