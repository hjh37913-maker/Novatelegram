package app.nova

import android.app.Application
import android.os.Build
import app.nova.data.LocalFolders
import app.nova.data.LocalHistory
import app.nova.data.LocalProfile
import app.nova.data.S
import app.nova.service.Notifier
import app.nova.tg.Tg
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.memory.MemoryCache

class NovaApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        S.init(this)
        Tg.app = this
        LocalFolders.load()
        LocalProfile.load()
        LocalHistory.load(this)
        Notifier.createChannels(this)
    }

    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components {
            if (Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory()) else add(GifDecoder.Factory())
        }
        .memoryCache { MemoryCache.Builder(this@NovaApp).maxSizePercent(S.imageCacheMb.v / 100.0).build() }
        .crossfade(true)
        .build()
}
