@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package app.nova.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nova.data.BoolS
import app.nova.data.ChoiceS
import app.nova.data.ColorS
import app.nova.data.IntS
import app.nova.data.S
import app.nova.data.Setting
import app.nova.data.TextS
import app.nova.data.argbOf
import app.nova.tg.Tg
import coil.compose.AsyncImage
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.layout.ExperimentalLayoutApi

// ------------------------------------------------------------------ navigation

sealed class Route {
    object Main : Route()
    data class Chat(val id: Long, val jumpTo: Long = 0) : Route()
    data class Profile(val userId: Long, val chatId: Long = 0) : Route()
    object EditProfile : Route()
    data class Search(val chatId: Long = 0) : Route()
    data class Settings(val section: String?) : Route()
    object ThemeEditor : Route()
    data class BannerEditor(val userId: Long) : Route()
    object Security : Route()
    object About : Route()
    object Folders : Route()
    object Downloads : Route()
    object Cache : Route()
    data class Media(val chatId: Long, val msgId: Long) : Route()
    data class Forward(val fromChat: Long, val ids: List<Long>) : Route()
}

object Nav {
    val stack = mutableStateListOf<Route>(Route.Main)
    var forward = true
    fun push(r: Route) { forward = true; stack.add(r) }
    fun pop() { if (stack.size > 1) { forward = false; stack.removeAt(stack.lastIndex) } }
    fun reset() { forward = false; stack.clear(); stack.add(Route.Main) }
    fun openChat(id: Long, jump: Long = 0) {
        // avoid stacking the same chat twice
        val top = stack.lastOrNull()
        if (top is Route.Chat && top.id == id) return
        push(Route.Chat(id, jump))
    }
}

// ------------------------------------------------------------------ small helpers

fun fmtTime(date: Int): String {
    val pattern = if (S.time12h.v) "h:mm a" else "HH:mm"
    return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(date * 1000L))
}

fun fmtListTime(date: Int): String {
    if (date == 0) return ""
    val now = System.currentTimeMillis()
    val t = date * 1000L
    val day = 86_400_000L
    return when {
        now - t < day -> fmtTime(date)
        now - t < 7 * day -> SimpleDateFormat("EEE", Locale.getDefault()).format(Date(t))
        else -> SimpleDateFormat("dd.MM.yy", Locale.getDefault()).format(Date(t))
    }
}

fun fmtDay(date: Int): String = SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(Date(date * 1000L))

fun dayKey(date: Int): Int = (date + java.util.TimeZone.getDefault().getOffset(date * 1000L) / 1000) / 86400

fun fmtSize(b: Long): String = when {
    b < 0 -> "?"
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "${b / 1024} KB"
    b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
}

fun fmtDur(s: Int) = String.format(Locale.US, "%d:%02d", s / 60, s % 60)

fun shapeFor(name: String): Shape = when (name) {
    "Circle" -> CircleShape
    "Squircle" -> RoundedCornerShape(30)
    else -> RoundedCornerShape(4.dp)
}

fun hashColor(s: String): Color {
    val colors = listOf(0xFFE17076, 0xFFFAA774, 0xFF7BC862, 0xFF6EC9CB, 0xFF65AADD, 0xFFA695E7, 0xFFEE7AAE)
    return Color(colors[(s.hashCode() and 0x7fffffff) % colors.size])
}

// ------------------------------------------------------------------ gestures / press

fun Modifier.springClick(onLong: (() -> Unit)? = null, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pressed && S.spring.v && !Motion.reduced) 0.96f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium), label = "press"
    )
    Modifier.scale(sc).combinedClickable(
        interactionSource = src, indication = null, onClick = onClick, onLongClick = onLong
    )
}

fun Modifier.edgeBack(): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        if (down.position.x > 36.dp.toPx() || !S.swipeBack.v) return@awaitEachGesture
        var dx = 0f
        do {
            val ev = awaitPointerEvent()
            dx += ev.changes.first().positionChange().x
        } while (ev.changes.any { it.pressed })
        if (dx > 90.dp.toPx()) Nav.pop()
    }
}

// ------------------------------------------------------------------ avatar

@Composable
fun Avatar(fileId: Int, title: String, size: Dp, shape: Shape = shapeFor(S.avatarShape.v), modifier: Modifier = Modifier) {
    val path by produceState<String?>(null, fileId) {
        value = if (fileId == 0) null else Tg.download(fileId, priority = 4)
    }
    Box(modifier.size(size).clip(shape).background(hashColor(title)), contentAlignment = Alignment.Center) {
        if (path != null) {
            AsyncImage(File(path!!), null, Modifier.size(size), contentScale = ContentScale.Crop)
        } else {
            Text(title.trim().take(1).uppercase(), color = Color.White, fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

// ------------------------------------------------------------------ top bar

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = Nav::pop, actions: @Composable () -> Unit = {}) {
    val c = Nova.c
    Row(
        Modifier.fillMaxWidth().background(c.surface).padding(horizontal = 4.dp).height(56.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = c.text) }
        } else Spacer(Modifier.width(12.dp))
        Text(title, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text.uppercase(), color = Nova.c.accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 6.dp))
}

@Composable
fun Divider() { HorizontalDivider(color = Nova.c.border) }

@Composable
fun ActionRow(title: String, desc: String = "", icon: androidx.compose.ui.graphics.vector.ImageVector? = null, danger: Boolean = false, onClick: () -> Unit) {
    val c = Nova.c
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) { Icon(icon, null, tint = if (danger) Color(0xFFFF5C5C) else c.accent); Spacer(Modifier.width(16.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, color = if (danger) Color(0xFFFF5C5C) else c.text, fontSize = 16.sp)
            if (desc.isNotEmpty()) Text(desc, color = c.sec, fontSize = 13.sp)
        }
    }
}

// ------------------------------------------------------------------ setting rows

@Composable
fun SettingRow(s: Setting) {
    val c = Nova.c
    when (s) {
        is BoolS -> Row(
            Modifier.fillMaxWidth().clickable { s.set(!s.v) }.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(s.title, color = c.text, fontSize = 16.sp)
                if (s.desc.isNotEmpty()) Text(s.desc, color = c.sec, fontSize = 13.sp)
            }
            Switch(
                s.v, { s.set(it) },
                colors = SwitchDefaults.colors(checkedTrackColor = c.accent, checkedThumbColor = Color.White, uncheckedTrackColor = c.surface2, uncheckedThumbColor = c.sec, uncheckedBorderColor = c.border)
            )
        }
        is IntS -> Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row {
                Text(s.title, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Text("${s.v}${s.unit}", color = c.accent, fontSize = 15.sp)
            }
            if (s.desc.isNotEmpty()) Text(s.desc, color = c.sec, fontSize = 13.sp)
            Slider(
                s.v.toFloat(), { s.set(it.toInt()) }, valueRange = s.min.toFloat()..s.max.toFloat(),
                colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.surface2)
            )
        }
        is ChoiceS -> {
            var open by remember { mutableStateOf(false) }
            Column(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(s.title, color = c.text, fontSize = 16.sp)
                Text(s.v, color = c.accent, fontSize = 14.sp)
                if (s.desc.isNotEmpty()) Text(s.desc, color = c.sec, fontSize = 13.sp)
            }
            if (open) PickDialog(s.title, s.options, s.v, { open = false }) { s.set(it); open = false }
        }
        is ColorS -> {
            var open by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.title, color = c.text, fontSize = 16.sp)
                    if (s.desc.isNotEmpty()) Text(s.desc, color = c.sec, fontSize = 13.sp)
                }
                Box(Modifier.size(28.dp).clip(CircleShape).background(s.color).border(1.dp, c.border, CircleShape))
            }
            if (open) ColorDialog(s.title, s.color, { open = false }) { s.set(it); open = false }
        }
        is TextS -> {
            var open by remember { mutableStateOf(false) }
            Column(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(s.title, color = c.text, fontSize = 16.sp)
                Text(s.v.ifEmpty { "—" }, color = c.accent, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (s.desc.isNotEmpty()) Text(s.desc, color = c.sec, fontSize = 13.sp)
            }
            if (open) TextDialog(s.title, s.v, { open = false }) { s.set(it); open = false }
        }
    }
}

@Composable
fun PickDialog(title: String, options: List<String>, current: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val c = Nova.c
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = c.surface2,
        title = { Text(title, color = c.text) },
        text = {
            Column {
                options.forEach { o ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(o) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (o == current) "●  $o" else "○  $o", color = if (o == current) c.accent else c.text, fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Cancel", color = c.accent) } }
    )
}

@Composable
fun TextDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    val c = Nova.c
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = c.surface2,
        title = { Text(title, color = c.text) },
        text = { OutlinedTextField(t, { t = it }, singleLine = false, textStyle = androidx.compose.ui.text.TextStyle(color = c.text)) },
        confirmButton = { TextButton({ onOk(t) }) { Text("OK", color = c.accent) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = c.sec) } }
    )
}

private val palette = listOf(
    0xFF4C8DFFL, 0xFF3DDC97L, 0xFFFF6B6BL, 0xFFFFB84DL, 0xFFB57BFFL, 0xFF2EC4D6L, 0xFFFF7AB6L, 0xFFE8E8EDL,
    0xFF000000L, 0xFF08090DL, 0xFF111318L, 0xFF171920L, 0xFF0E1621L, 0xFF1F2C3AL, 0xFFF6F7FAL, 0xFFFFFFFFL
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorDialog(title: String, initial: Color, onDismiss: () -> Unit, onPick: (Color) -> Unit) {
    val c = Nova.c
    var hex by remember { mutableStateOf(String.format("%06X", argbOf(initial) and 0xFFFFFFL)) }
    val parsed = remember(hex) {
        try { Color(("FF" + hex.padStart(6, '0').takeLast(6)).toLong(16)) } catch (e: Exception) { null }
    }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = c.surface2,
        title = { Text(title, color = c.text) },
        text = {
            Column {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    palette.forEach { p ->
                        Box(Modifier.size(36.dp).clip(CircleShape).background(Color(p)).border(1.dp, c.border, CircleShape).clickable { hex = String.format("%06X", p and 0xFFFFFFL) })
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(hex, { hex = it.filter { ch -> ch.isLetterOrDigit() }.take(6).uppercase() }, label = { Text("HEX") }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = c.text))
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(28.dp).clip(RoundedCornerShape(8.dp)).background(parsed ?: Color.Gray))
            }
        },
        confirmButton = { TextButton({ parsed?.let(onPick) }) { Text("OK", color = c.accent) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = c.sec) } }
    )
}
