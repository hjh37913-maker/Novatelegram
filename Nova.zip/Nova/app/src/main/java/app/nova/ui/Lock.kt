package app.nova.ui

import android.os.SystemClock
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import app.nova.data.Pin
import app.nova.data.S

object Lock {
    var locked by mutableStateOf(false)
    private var stopAt = 0L

    fun init() { locked = S.appLock.v && Pin.isSet() }
    fun lockNow() { if (S.appLock.v && Pin.isSet()) locked = true }
    fun onStop() { stopAt = SystemClock.elapsedRealtime() }

    fun onStart() {
        if (!S.appLock.v || !Pin.isSet()) { locked = false; return }
        if (stopAt == 0L) return
        val limit = when (S.autoLock.v) { "Immediately" -> 0L; "1 minute" -> 60_000L; "5 minutes" -> 300_000L; else -> 3_600_000L }
        if (SystemClock.elapsedRealtime() - stopAt >= limit) locked = true
    }

    fun biometricAvailable(a: FragmentActivity): Boolean =
        BiometricManager.from(a).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
}

@Composable
fun PinPad(title: String, error: String, onSubmit: (String) -> Unit, extra: @Composable () -> Unit = {}) {
    val c = Nova.c
    var pin by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(title, color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(8) { i -> Box(Modifier.size(14.dp).clip(CircleShape).background(if (i < pin.length) c.accent else c.surface2)) }
        }
        Spacer(Modifier.height(8.dp))
        Text(error, color = Color(0xFFFF5C5C), fontSize = 14.sp, modifier = Modifier.height(22.dp))
        Spacer(Modifier.height(12.dp))
        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "OK"))
        rows.forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                r.forEach { k ->
                    Box(
                        Modifier.size(72.dp).clip(CircleShape).background(c.surface2).springClick {
                            when (k) {
                                "⌫" -> pin = pin.dropLast(1)
                                "OK" -> if (pin.length >= 4) { val p = pin; pin = ""; onSubmit(p) }
                                else -> if (pin.length < 8) pin += k
                            }
                        },
                        contentAlignment = Alignment.Center
                    ) { Text(k, color = c.text, fontSize = 24.sp) }
                }
            }
        }
        extra()
    }
}

@Composable
fun LockScreen(activity: FragmentActivity) {
    val c = Nova.c
    var error by remember { mutableStateOf("") }
    var fails by remember { mutableStateOf(0) }
    val ctx = LocalContext.current

    fun prompt() {
        if (!S.biometric.v || !Lock.biometricAvailable(activity)) return
        val executor = ContextCompat.getMainExecutor(ctx)
        val bp = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { Lock.locked = false }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Nova")
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        bp.authenticate(info)
    }

    LaunchedEffect(Unit) { prompt() }

    Box(Modifier.fillMaxSize().background(c.bg).clickable(enabled = false) {}) {
        PinPad("Enter PIN", error, onSubmit = { p ->
            if (Pin.verify(p)) { Lock.locked = false; error = ""; fails = 0 }
            else { fails++; error = "Wrong PIN" + if (fails >= 3) " ($fails attempts)" else "" }
        }) {
            if (S.biometric.v && Lock.biometricAvailable(activity)) {
                TextButton({ prompt() }) { Text("Use biometrics", color = c.accent) }
            }
        }
    }
}
