@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)

package app.nova.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import app.nova.BuildConfig
import app.nova.data.*
import app.nova.tg.*
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi
import java.io.File
import java.util.Calendar

// ------------------------------------------------------------------ search

@Composable
fun SearchScreen(chatId: Long, embedded: Boolean = false) {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("All") }
    var range by remember { mutableStateOf("Any time") }
    var sender by remember { mutableStateOf(0L) }
    var hits by remember { mutableStateOf<List<Hit>>(emptyList()) }
    var chatsFound by remember { mutableStateOf<List<ChatRow>>(emptyList()) }
    var pub by remember { mutableStateOf<List<Long>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(S.str("search_hist").split("\n").filter { it.isNotBlank() }) }
    val all by Tg.chats.collectAsState()
    val me by Tg.me.collectAsState()

    fun run() {
        if (q.isBlank() && type == "All") return
        busy = true
        if (q.isNotBlank()) { history = (listOf(q) + history.filter { it != q }).take(15); S.setStr("search_hist", history.joinToString("\n")) }
        scope.launch {
            val now = (System.currentTimeMillis() / 1000).toInt()
            val min = when (range) { "Today" -> now - 86400; "Week" -> now - 7 * 86400; "Month" -> now - 30 * 86400; "Year" -> now - 365 * 86400; else -> 0 }
            try {
                hits = if (chatId != 0L) Tg.searchInChat(chatId, q, type, sender) else Tg.searchGlobal(q, type, min, 0)
                if (chatId == 0L && q.isNotBlank()) {
                    chatsFound = all.filter { it.title.contains(q, true) }.take(10)
                    pub = if (q.startsWith("@") || q.length >= 4) Tg.searchPublic(q).filter { id -> chatsFound.none { it.id == id } } else emptyList()
                } else { chatsFound = emptyList(); pub = emptyList() }
            } catch (e: Exception) { hits = emptyList() }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(if (chatId != 0L) "Search in chat" else "Search", onBack = if (embedded) null else Nav::pop)
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { NField(q, { q = it }, "Chats, messages, @username") }
            IconButton({ run() }) { Icon(Icons.Filled.Search, null, tint = c.accent) }
        }
        FlowRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("All", "Photos", "Videos", "Documents", "GIFs", "Voice", "Links").forEach { t -> FolderChip(t, type == t, null) { type = t; run() } }
        }
        if (chatId == 0L) FlowRow(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Any time", "Today", "Week", "Month", "Year").forEach { t -> FolderChip(t, range == t, null) { range = t; run() } }
        } else Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FolderChip("Anyone", sender == 0L, null) { sender = 0L; run() }
            me?.let { m -> FolderChip("From me", sender == m.id, null) { sender = m.id; run() } }
            (Tg.chatCache[chatId]?.type as? TdApi.ChatTypePrivate)?.let { p -> if (p.userId != me?.id) FolderChip("From them", sender == p.userId, null) { sender = p.userId; run() } }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = c.accent)
        LazyColumn(Modifier.weight(1f)) {
            if (hits.isEmpty() && chatsFound.isEmpty() && q.isBlank() && history.isNotEmpty()) {
                item { Row(Modifier.padding(16.dp)) { Text("Recent", color = c.sec, modifier = Modifier.weight(1f)); Text("Clear", color = c.accent, modifier = Modifier.clickable { history = emptyList(); S.setStr("search_hist", "") }) } }
                items(history) { h -> Text(h, color = c.text, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { q = h; run() }.padding(horizontal = 16.dp, vertical = 10.dp)) }
            }
            if (chatsFound.isNotEmpty()) { item { SectionLabel("Chats") }; items(chatsFound, key = { "c" + it.id }) { r -> SimpleChatRow(r.photoId, r.title, r.last) { Nav.openChat(r.id) } } }
            if (pub.isNotEmpty()) { item { SectionLabel("Global") }; items(pub, key = { "p" + it }) { id -> Tg.chatCache[id]?.let { ch -> SimpleChatRow(ch.photo?.small?.id ?: 0, ch.title, "") { Nav.openChat(id) } } } }
            if (hits.isNotEmpty()) {
                item { SectionLabel("Messages (${hits.size})") }
                items(hits, key = { "m" + it.msg.chatId + ":" + it.msg.id }) { h ->
                    Column(Modifier.fillMaxWidth().clickable { Nav.openChat(h.msg.chatId, h.msg.id) }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Row { Text(h.chatTitle, color = c.accent, fontSize = 13.sp, modifier = Modifier.weight(1f)); Text(fmtListTime(h.msg.date), color = c.sec, fontSize = 12.sp) }
                        Text(h.msg.text.ifBlank { Tg.kindLabel(h.msg.kind) }, color = c.text, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Divider()
                }
            } else if (!busy && q.isNotBlank() && chatsFound.isEmpty()) item { Text("Nothing found", color = c.sec, modifier = Modifier.padding(24.dp)) }
        }
    }
}

@Composable
fun SimpleChatRow(photo: Int, title: String, sub: String, onClick: () -> Unit) {
    val c = Nova.c
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(photo, title, 42.dp)
        Column(Modifier.padding(start = 12.dp)) {
            Text(title, color = c.text, fontSize = 16.sp, maxLines = 1)
            if (sub.isNotBlank()) Text(sub, color = c.sec, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ------------------------------------------------------------------ forward

@Composable
fun ForwardScreen(r: Route.Forward) {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    val all by Tg.chats.collectAsState()
    var q by remember { mutableStateOf("") }
    val picked = remember { mutableStateListOf<Long>() }
    var asCopy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Forward ${r.ids.size} message(s)") {
            TextButton(enabled = picked.isNotEmpty(), onClick = {
                scope.launch { picked.forEach { try { Tg.forward(it, r.fromChat, r.ids, asCopy) } catch (e: Exception) { } }; Nav.pop() }
            }) { Text("Send (${picked.size})", color = if (picked.isNotEmpty()) c.accent else c.sec) }
        }
        Box(Modifier.padding(12.dp)) { NField(q, { q = it }, "Search") }
        ToggleRow("Send as copy (hide sender)", asCopy) { asCopy = it }
        LazyColumn(Modifier.weight(1f)) {
            items(all.filter { !it.archived && (q.isBlank() || it.title.contains(q, true)) }.sortedByDescending { it.order }, key = { it.id }) { ch ->
                Row(Modifier.fillMaxWidth().clickable { if (ch.id in picked) picked.remove(ch.id) else picked.add(ch.id) }.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(ch.photoId, ch.title, 42.dp); Text(ch.title, color = c.text, fontSize = 16.sp, modifier = Modifier.padding(start = 12.dp).weight(1f))
                    Checkbox(ch.id in picked, null, colors = CheckboxDefaults.colors(checkedColor = c.accent))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ media viewer

@Composable
fun MediaViewerScreen(r: Route.Media) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(Tg.cachedMediaFor(r.chatId)) }
    LaunchedEffect(Unit) {
        val extra = (Tg.mediaOf(r.chatId, "Photos") + Tg.mediaOf(r.chatId, "Videos") + Tg.mediaOf(r.chatId, "GIFs")).associateBy { it.id }
        items = (items.associateBy { it.id } + extra).values.sortedBy { it.id }
    }
    val start = items.indexOfFirst { it.id == r.msgId }.coerceAtLeast(0)
    if (items.isEmpty()) { Box(Modifier.fillMaxSize().background(Color.Black)); return }
    val pager = rememberPagerState(start) { items.size }
    LaunchedEffect(items.size) { if (start < items.size) pager.scrollToPage(start) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
            val m = items[page]
            var path by remember(m.fileId) { mutableStateOf<String?>(null) }
            LaunchedEffect(m.fileId) { path = Tg.download(m.fileId, "media", 16) }
            var scale by remember { mutableFloatStateOf(1f) }; var off by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
            val ts = rememberTransformableState { z, p, _ -> scale = (scale * z).coerceIn(1f, 6f); off = if (scale > 1f) off + p else androidx.compose.ui.geometry.Offset.Zero }
            Box(Modifier.fillMaxSize().transformable(ts, lockRotationOnZoomPan = true), contentAlignment = Alignment.Center) {
                if (path == null) CircularProgressIndicator(color = Color.White)
                else if (m.kind == MKind.VIDEO) AndroidView({ c ->
                    androidx.media3.ui.PlayerView(c).apply {
                        val p = androidx.media3.exoplayer.ExoPlayer.Builder(c).build(); p.setMediaItem(androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(File(path!!)))); p.prepare(); p.playWhenReady = true; player = p
                    }
                }, onRelease = { it.player?.release() })
                else AsyncImage(File(path!!), null, Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y }, contentScale = ContentScale.Fit)
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(Nav::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
            Text("${pager.currentPage + 1} / ${items.size}", color = Color.White, modifier = Modifier.weight(1f))
            IconButton({ items.getOrNull(pager.currentPage)?.let { m -> scope.launch { Tg.localPath(m.fileId)?.let { openFile(ctx, it) } } } }) { Icon(Icons.Filled.OpenInNew, null, tint = Color.White) }
            IconButton({ items.getOrNull(pager.currentPage)?.let { Nav.push(Route.Forward(r.chatId, listOf(it.id))) } }) { Icon(Icons.Filled.Share, null, tint = Color.White) }
        }
    }
}

// ------------------------------------------------------------------ settings

@Composable
fun SettingsScreen(section: String?, embedded: Boolean = false) {
    val c = Nova.c
    val me by Tg.me.collectAsState()
    if (section == null) {
        Column(Modifier.fillMaxSize()) {
            TopBar("Settings", onBack = if (embedded) null else Nav::pop)
            Column(Modifier.verticalScroll(rememberScrollState())) {
                me?.let { u ->
                    Row(Modifier.fillMaxWidth().clickable { Nav.push(Route.Profile(u.id)) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u.profilePhoto?.small?.id ?: 0, u.firstName, 56.dp)
                        Column(Modifier.padding(start = 14.dp)) { Text((u.firstName + " " + u.lastName).trim(), color = c.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text("+" + u.phoneNumber, color = c.sec, fontSize = 13.sp) }
                    }
                    Divider()
                }
                ActionRow("Appearance", "Theme, colours, chat look, animations, navigation", Icons.Filled.Palette) { Nav.push(Route.Settings("appearance")) }
                ActionRow("Chats", "Chat list, messages, media, gestures", Icons.Filled.Chat) { Nav.push(Route.Settings("chats")) }
                ActionRow("Profile", "Banner, avatar, status, customization", Icons.Filled.Person) { Nav.push(Route.Settings("profile")) }
                ActionRow("Privacy", "Account, messages, notifications, app lock", Icons.Filled.Lock) { Nav.push(Route.Settings("privacy")) }
                ActionRow("Performance", "Cache, downloads, network, battery", Icons.Filled.Speed) { Nav.push(Route.Settings("performance")) }
                ActionRow("Advanced", "Experimental, debug, about", Icons.Filled.Tune) { Nav.push(Route.Settings("advanced")) }
                Divider()
                ActionRow("Theme editor", "Build your own colours with live preview", Icons.Filled.Brush) { Nav.push(Route.ThemeEditor) }
                ActionRow("Folders", "Local folders, order, icons", Icons.Filled.Folder) { Nav.push(Route.Folders) }
                ActionRow("Security center", "PIN, sessions, account privacy", Icons.Filled.Security) { Nav.push(Route.Security) }
                ActionRow("Downloads", "Download manager", Icons.Filled.Download) { Nav.push(Route.Downloads) }
                ActionRow("Cache", "Storage and cleanup", Icons.Filled.CleaningServices) { Nav.push(Route.Cache) }
                ActionRow("About", "", Icons.Filled.Info) { Nav.push(Route.About) }
                Spacer(Modifier.height(24.dp))
            }
        }
        return
    }
    val title = section.replaceFirstChar { it.uppercase() }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        TopBar(title)
        Column(Modifier.verticalScroll(rememberScrollState())) {
            S.groups[section]?.forEach { g ->
                SectionLabel(g.title)
                g.items.forEach { SettingRow(it) }
            }
            when (section) {
                "appearance" -> {
                    SectionLabel("Tools")
                    ActionRow("Open theme editor", icon = Icons.Filled.Brush) { Nav.push(Route.ThemeEditor) }
                    ActionRow("Reset appearance", icon = Icons.Filled.RestartAlt, danger = true) { S.resetAppearance() }
                }
                "profile" -> {
                    SectionLabel("Banner")
                    ActionRow("Banner editor", "Photo, video, GIF or animated gradient", Icons.Filled.Image) { me?.let { Nav.push(Route.BannerEditor(it.id)) } }
                    ActionRow("Edit profile", icon = Icons.Filled.Edit) { Nav.push(Route.EditProfile) }
                }
                "privacy" -> {
                    SectionLabel("Security")
                    ActionRow("Security center", "PIN code, sessions, last seen & photo visibility", Icons.Filled.Security) { Nav.push(Route.Security) }
                }
                "performance" -> {
                    SectionLabel("Storage")
                    ActionRow("Cache & storage", icon = Icons.Filled.CleaningServices) { Nav.push(Route.Cache) }
                    ActionRow("Download manager", icon = Icons.Filled.Download) { Nav.push(Route.Downloads) }
                    SectionLabel("Network")
                    ActionRow("Proxy / network", "Network type is reported to TDLib automatically (Wi-Fi / mobile)") {}
                }
                "advanced" -> {
                    SectionLabel("About")
                    ActionRow("About Nova", icon = Icons.Filled.Info) { Nav.push(Route.About) }
                    ActionRow("Clear local history (kept deleted messages & edits)", icon = Icons.Filled.DeleteSweep, danger = true) { LocalHistory.clearAll() }
                    ActionRow("Log out", icon = Icons.Filled.Logout, danger = true) { scope.launch { try { Tg.logout() } catch (e: Exception) { } } }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ------------------------------------------------------------------ theme editor

@Composable
fun ThemeEditorScreen() {
    val c = Nova.c
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    LaunchedEffect(Unit) { if (S.themeMode.v != "Custom") { copyPaletteToCustom(S.themeMode.v, true); S.themeMode.set("Custom") } }
    Column(Modifier.fillMaxSize()) {
        TopBar("Theme editor")
        // live preview
        Column(Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(16.dp)).background(c.bg).border(1.dp, c.border, RoundedCornerShape(16.dp))) {
            Row(Modifier.fillMaxWidth().background(c.surface).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(28.dp).clip(CircleShape).background(c.accent)); Text("  Preview", color = c.text, fontWeight = FontWeight.SemiBold); Spacer(Modifier.weight(1f)); Icon(Icons.Filled.Search, null, tint = c.icon) }
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Hello! This is an incoming message", color = c.text, modifier = Modifier.clip(RoundedCornerShape(S.bubbleRadius.v.dp)).background(c.bubbleIn).padding(10.dp))
                Text("And this is an outgoing one", color = c.text, modifier = Modifier.align(Alignment.End).clip(RoundedCornerShape(S.bubbleRadius.v.dp)).background(c.bubbleOut).padding(10.dp))
                Text("Secondary text sample", color = c.sec, fontSize = 13.sp)
            }
            Row(Modifier.fillMaxWidth().background(c.nav).padding(10.dp), horizontalArrangement = Arrangement.SpaceEvenly) { Icon(Icons.Filled.Chat, null, tint = c.accent); Icon(Icons.Filled.Contacts, null, tint = c.icon); Icon(Icons.Filled.Settings, null, tint = c.icon) }
        }
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Dark", "AMOLED", "Light", "Classic").forEach { p -> FolderChip("From $p", false, null) { copyPaletteToCustom(p, true) } }
            }
            listOf<Setting>(S.accent, S.cBg, S.cSurface, S.cSurface2, S.cText, S.cSec, S.cBubbleIn, S.cBubbleOut, S.cBorder, S.cIcons, S.cNav).forEach { SettingRow(it) }
            SettingRow(S.bubbleRadius)
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ------------------------------------------------------------------ security

@Composable
fun SecurityScreen() {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    var sessions by remember { mutableStateOf<List<TdApi.Session>>(emptyList()) }
    var setPin by remember { mutableStateOf(false) }
    var pinSet by remember { mutableStateOf(Pin.isSet()) }
    var privacy by remember { mutableStateOf(mapOf<String, String>()) }
    var pickFor by remember { mutableStateOf<String?>(null) }
    var msg by remember { mutableStateOf("") }
    fun load() = scope.launch {
        sessions = try { Tg.sessions() } catch (e: Exception) { emptyList() }
        privacy = listOf("status", "photo", "phone").associateWith { Tg.getPrivacy(it) }
    }
    LaunchedEffect(Unit) { load() }
    if (setPin) {
        var first by remember { mutableStateOf<String?>(null) }; var err by remember { mutableStateOf("") }
        Box(Modifier.fillMaxSize().background(c.bg)) {
            PinPad(if (first == null) "New PIN (4–8 digits)" else "Repeat PIN", err, { p ->
                if (first == null) first = p else if (first == p) { Pin.set(p); pinSet = true; S.appLock.set(true); setPin = false } else { err = "PINs do not match"; first = null }
            }) { TextButton({ setPin = false }) { Text("Cancel", color = c.accent) } }
        }
        return
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("Security center")
        Column(Modifier.verticalScroll(rememberScrollState())) {
            SectionLabel("App lock")
            ActionRow(if (pinSet) "Change PIN" else "Set PIN", icon = Icons.Filled.Pin) { setPin = true }
            if (pinSet) ActionRow("Remove PIN", icon = Icons.Filled.LockOpen, danger = true) { Pin.clear(); pinSet = false; S.appLock.set(false); S.biometric.set(false) }
            SettingRow(S.appLock); SettingRow(S.biometric); SettingRow(S.autoLock); SettingRow(S.screenshotProt)
            SectionLabel("Visible to others (Telegram server)")
            listOf("status" to "Last seen & online", "photo" to "Profile photo", "phone" to "Phone number").forEach { (k, t) ->
                ActionRow(t, privacy[k] ?: "…") { pickFor = k }
            }
            if (msg.isNotEmpty()) Text(msg, color = c.sec, modifier = Modifier.padding(16.dp))
            SectionLabel("Active sessions")
            sessions.forEach { s ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.deviceModel + if (s.isCurrent) "  (this device)" else "", color = c.text, fontSize = 15.sp)
                        Text("${s.applicationName} · ${s.platform} · ${s.country}", color = c.sec, fontSize = 12.sp)
                    }
                    if (!s.isCurrent) TextButton({ scope.launch { try { Tg.terminate(s.id); load() } catch (e: Exception) { msg = e.message ?: "" } } }) { Text("End", color = Color(0xFFFF5C5C)) }
                }
            }
        }
    }
    pickFor?.let { k ->
        PickDialog("Who can see", listOf("Everybody", "My contacts", "Nobody"), privacy[k] ?: "", { pickFor = null }) { v ->
            pickFor = null
            scope.launch { try { Tg.setPrivacy(k, v); msg = "Saved. Custom exceptions for this setting were replaced."; load() } catch (e: Exception) { msg = e.message ?: "Error" } }
        }
    }
}

// ------------------------------------------------------------------ about

@Composable
fun AboutScreen() {
    val c = Nova.c
    var v by remember { mutableStateOf("…") }
    LaunchedEffect(Unit) { v = Tg.tdVersion() }
    Column(Modifier.fillMaxSize()) {
        TopBar("About")
        Column(Modifier.padding(24.dp)) {
            Text("Nova", color = c.text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Unofficial Telegram client · version 1.0", color = c.sec)
            Spacer(Modifier.height(16.dp))
            Text("TDLib $v (Boost Software License 1.0)", color = c.text)
            Spacer(Modifier.height(16.dp))
            Text("Not affiliated with Telegram. Server-side states (online, read receipts, typing) are only changed through what the official API allows. Calls and Stories are not included in this build.", color = c.sec, fontSize = 14.sp)
        }
    }
}

// ------------------------------------------------------------------ folders

@Composable
fun FoldersScreen() {
    val c = Nova.c
    val all by Tg.chats.collectAsState()
    var editing by remember { mutableStateOf<LocalFolder?>(null) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Folders") { TextButton({ editing = LocalFolder(System.currentTimeMillis().toString(), "", "📁", emptyList()) }) { Text("New", color = c.accent) } }
        LazyColumn {
            items(LocalFolders.list.toList(), key = { it.id }) { f ->
                Row(Modifier.fillMaxWidth().clickable { editing = f }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(f.icon, fontSize = 24.sp); Column(Modifier.padding(start = 12.dp).weight(1f)) { Text(f.name, color = c.text, fontSize = 16.sp); Text("${f.chatIds.size} chats", color = c.sec, fontSize = 12.sp) }
                    IconButton({ LocalFolders.move(f.id, -1) }) { Icon(Icons.Filled.KeyboardArrowUp, null, tint = c.icon) }
                    IconButton({ LocalFolders.move(f.id, 1) }) { Icon(Icons.Filled.KeyboardArrowDown, null, tint = c.icon) }
                }
            }
            item { Text("Local folders live only in this app. Telegram's own folders are not changed.", color = c.sec, fontSize = 12.sp, modifier = Modifier.padding(16.dp)) }
        }
    }
    editing?.let { f ->
        var name by remember(f.id) { mutableStateOf(f.name) }; var icon by remember(f.id) { mutableStateOf(f.icon) }
        val ids = remember(f.id) { mutableStateListOf<Long>().apply { addAll(f.chatIds) } }
        AlertDialog({ editing = null }, containerColor = c.surface2, title = { Text("Folder", color = c.text) },
            text = { Column {
                Row { Box(Modifier.width(72.dp)) { NField(icon, { icon = it.take(2) }, "Icon") }; Spacer(Modifier.width(8.dp)); NField(name, { name = it }, "Name") }
                LazyColumn(Modifier.height(280.dp)) { items(all.filter { !it.archived }.sortedByDescending { it.order }, key = { it.id }) { ch ->
                    Row(Modifier.fillMaxWidth().clickable { if (ch.id in ids) ids.remove(ch.id) else ids.add(ch.id) }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(ch.id in ids, null, colors = CheckboxDefaults.colors(checkedColor = c.accent)); Text(ch.title, color = c.text, maxLines = 1)
                    } } }
            } },
            confirmButton = { TextButton({ if (name.isNotBlank()) LocalFolders.upsert(LocalFolder(f.id, name, icon.ifBlank { "📁" }, ids.toList())); editing = null }) { Text("Save", color = c.accent) } },
            dismissButton = { Row { if (LocalFolders.list.any { it.id == f.id }) TextButton({ LocalFolders.remove(f.id); editing = null }) { Text("Delete", color = Color(0xFFFF5C5C)) }; TextButton({ editing = null }) { Text("Cancel", color = c.sec) } } })
    }
}

// ------------------------------------------------------------------ downloads / cache

@Composable
fun DownloadsScreen() {
    val c = Nova.c
    val files by Tg.files.collectAsState()
    Column(Modifier.fillMaxSize()) {
        TopBar("Download manager")
        LazyColumn {
            items(files.values.toList().sortedByDescending { it.active }, key = { it.id }) { f ->
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(f.name, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(if (f.completed) "Done · ${fmtSize(f.size)}" else "${fmtSize(f.done)} / ${fmtSize(f.size)}", color = c.sec, fontSize = 12.sp) }
                        if (f.active) IconButton({ Tg.cancelDownload(f.id) }) { Icon(Icons.Filled.Close, null, tint = c.icon) }
                        else if (f.completed) IconButton({ openFile(Tg.app, f.path) }) { Icon(Icons.Filled.OpenInNew, null, tint = c.icon) }
                    }
                    if (!f.completed && f.size > 0) LinearProgressIndicator(progress = { f.done.toFloat() / f.size }, Modifier.fillMaxWidth().padding(top = 6.dp), color = c.accent)
                }
                Divider()
            }
            if (files.isEmpty()) item { Text("No downloads in this session. Tap a file in a chat to download it.", color = c.sec, modifier = Modifier.padding(24.dp)) }
        }
    }
}

@Composable
fun CacheScreen() {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    var size by remember { mutableStateOf(-1L) }
    var busy by remember { mutableStateOf(false) }
    fun load() = scope.launch { size = Tg.storageBytes() }
    LaunchedEffect(Unit) { load() }
    Column(Modifier.fillMaxSize()) {
        TopBar("Cache")
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text("Telegram files: ${if (size < 0) "…" else fmtSize(size)}", color = c.text, fontSize = 20.sp, modifier = Modifier.padding(16.dp))
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = c.accent)
            ActionRow("Delete files older than ${S.autoCleanDays.v} days", icon = Icons.Filled.CleaningServices) { scope.launch { busy = true; try { Tg.optimize(S.autoCleanDays.v) } catch (e: Exception) { }; busy = false; load() } }
            ActionRow("Delete all cached files", "Messages stay, files re-download on demand", Icons.Filled.DeleteForever, danger = true) { scope.launch { busy = true; try { Tg.optimize(0, all = true) } catch (e: Exception) { }; busy = false; load() } }
            SettingRow(S.autoClean); SettingRow(S.autoCleanDays); SettingRow(S.imageCacheMb)
            SectionLabel("Downloads")
            SettingRow(S.autoPhoto); SettingRow(S.autoVideo); SettingRow(S.autoMaxMb); SettingRow(S.autoWifiOnly); SettingRow(S.lowData)
        }
    }
}
