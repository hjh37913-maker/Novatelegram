package app.nova.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.nova.MainActivity
import app.nova.data.S
import app.nova.tg.Tg
import org.drinkless.tdlib.TdApi
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

object Notifier {
    private const val CH_PRIVATE = "msg_private"
    private const val CH_GROUP = "msg_group"
    private const val CH_CHANNEL = "msg_channel"
    const val CH_SERVICE = "service"
    private val lines = ConcurrentHashMap<Long, MutableList<String>>()

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PRIVATE, "Private chats", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_GROUP, "Groups", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_CHANNEL, "Channels", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Background connection", NotificationManager.IMPORTANCE_MIN))
    }

    fun onMessage(ctx: Context, m: TdApi.Message, chat: TdApi.Chat) {
        if (!S.notifOn.v) return
        if (chat.notificationSettings.muteFor > 0) return
        if (chat.positions.none { it.list is TdApi.ChatListMain && it.order != 0L }) return
        if (Tg.foreground && Tg.openChat == chat.id) return
        val nmc = NotificationManagerCompat.from(ctx)
        if (!nmc.areNotificationsEnabled()) return

        val hide = S.notifHideText.v
        val body = if (hide) "New message" else Tg.describe(m.content)
        val sender = if (chat.type is TdApi.ChatTypePrivate) "" else (Tg.userName((m.senderId as? TdApi.MessageSenderUser)?.userId ?: 0L).let { if (it.isEmpty()) "" else "$it: " })
        val list = lines.getOrPut(chat.id) { mutableListOf() }
        synchronized(list) { list.add(if (hide) body else sender + body); while (list.size > 6) list.removeAt(0) }

        val channel = if (!S.notifPriority.v) CH_GROUP else when (val t = chat.type) {
            is TdApi.ChatTypePrivate, is TdApi.ChatTypeSecret -> CH_PRIVATE
            is TdApi.ChatTypeSupergroup -> if (t.isChannel) CH_CHANNEL else CH_GROUP
            else -> CH_GROUP
        }
        val open = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("chat", chat.id)
        }
        val pi = PendingIntent.getActivity(ctx, abs(chat.id.hashCode()), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val style = NotificationCompat.InboxStyle()
        synchronized(list) { list.forEach { style.addLine(it) } }
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(if (hide) "Nova" else chat.title)
            .setContentText(if (hide) body else sender + body)
            .setStyle(style)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setWhen(m.date * 1000L)
        if (S.notifGroup.v) b.setGroup("nova_msgs")
        try {
            nmc.notify(abs(chat.id.hashCode()), b.build())
            if (S.notifGroup.v) {
                val sum = NotificationCompat.Builder(ctx, CH_GROUP)
                    .setSmallIcon(android.R.drawable.stat_notify_chat)
                    .setContentTitle("Nova").setGroup("nova_msgs").setGroupSummary(true).setAutoCancel(true).build()
                nmc.notify(1, sum)
            }
        } catch (e: SecurityException) { }
    }

    fun clear(ctx: Context, chatId: Long) {
        lines.remove(chatId)
        try { NotificationManagerCompat.from(ctx).cancel(abs(chatId.hashCode())) } catch (e: Exception) { }
    }
}

class KeepAliveService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifier.createChannels(this)
        val n: Notification = NotificationCompat.Builder(this, Notifier.CH_SERVICE)
            .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
            .setContentTitle("Nova is connected")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)
        return START_STICKY
    }
}
