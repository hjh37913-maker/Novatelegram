package app.nova.ui

import android.os.PowerManager
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import app.nova.data.S

@Immutable
class NovaColors(
    val bg: Color, val surface: Color, val surface2: Color, val text: Color, val sec: Color,
    val accent: Color, val border: Color, val bubbleIn: Color, val bubbleOut: Color,
    val icon: Color, val nav: Color, val light: Boolean
)

val LocalNova = staticCompositionLocalOf<NovaColors> { error("NovaTheme missing") }

object Nova {
    val c: NovaColors @Composable get() = LocalNova.current
}

fun novaColors(sysDark: Boolean): NovaColors {
    val accent = S.accent.color
    var mode = S.themeMode.v
    if (S.followSystem.v && (mode == "Dark" || mode == "Light")) mode = if (sysDark) "Dark" else "Light"
    fun out(surface2: Color) = lerp(surface2, accent, 0.55f)
    return when (mode) {
        "AMOLED" -> NovaColors(
            Color.Black, Color(0xFF0A0A0A), Color(0xFF131313), Color.White, Color(0xFF9A9EA8),
            accent, Color(0xFF1C1C1C), Color(0xFF151515), out(Color(0xFF151515)), Color(0xFFD0D3DB), Color.Black, false
        )
        "Light" -> NovaColors(
            Color(0xFFF6F7FA), Color.White, Color(0xFFEEF0F5), Color(0xFF101114), Color(0xFF6B7080),
            accent, Color(0xFFE1E4EB), Color(0xFFFFFFFF), lerp(Color.White, accent, 0.28f), Color(0xFF30343D), Color.White, true
        )
        "Classic" -> NovaColors(
            Color(0xFF0E1621), Color(0xFF17212B), Color(0xFF1F2C3A), Color.White, Color(0xFF7F91A4),
            accent, Color(0xFF242F3D), Color(0xFF182533), lerp(Color(0xFF182533), accent, 0.65f), Color(0xFFB7C4D1), Color(0xFF17212B), false
        )
        "Custom" -> NovaColors(
            S.cBg.color, S.cSurface.color, S.cSurface2.color, S.cText.color, S.cSec.color,
            accent, S.cBorder.color, S.cBubbleIn.color, S.cBubbleOut.color, S.cIcons.color, S.cNav.color,
            S.cBg.color.luminanceApprox() > 0.5f
        )
        else -> NovaColors(
            Color(0xFF08090D), Color(0xFF111318), Color(0xFF171920), Color.White, Color(0xFF969AA5),
            accent, Color(0xFF1F222B), Color(0xFF171920), out(Color(0xFF171920)), Color(0xFFC9CCD6), Color(0xFF0D0F14), false
        )
    }
}

private fun Color.luminanceApprox(): Float = 0.299f * red + 0.587f * green + 0.114f * blue

/** Palette presets copied into the Custom theme. */
fun copyPaletteToCustom(from: String, sysDark: Boolean) {
    val saved = S.themeMode.v
    S.themeMode.set(from)
    val c = novaColors(sysDark)
    S.themeMode.set(saved)
    S.cBg.set(c.bg); S.cSurface.set(c.surface); S.cSurface2.set(c.surface2); S.cText.set(c.text)
    S.cSec.set(c.sec); S.cBubbleIn.set(c.bubbleIn); S.cBubbleOut.set(c.bubbleOut)
    S.cBorder.set(c.border); S.cIcons.set(c.icon); S.cNav.set(c.nav)
}

fun reducedMotionNow(ctx: android.content.Context): Boolean {
    if (S.reduced.v) return true
    if (S.batteryNoAnim.v) {
        try { if (ctx.getSystemService(PowerManager::class.java).isPowerSaveMode) return true } catch (e: Exception) { }
    }
    return false
}

object Motion {
    var reduced = false
    /** Duration in ms adjusted by the user's animation speed. */
    fun ms(base: Int): Int = if (reduced) 0 else (base * 100f / S.animSpeed.v).toInt().coerceAtLeast(1)
}

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val ctx = LocalContext.current
    Motion.reduced = reducedMotionNow(ctx)
    val c = novaColors(sys)
    val scheme = if (c.light) lightColorScheme(
        primary = c.accent, onPrimary = Color.White, background = c.bg, onBackground = c.text,
        surface = c.surface, onSurface = c.text, surfaceVariant = c.surface2, onSurfaceVariant = c.sec,
        outline = c.border, secondaryContainer = c.surface2, onSecondaryContainer = c.text
    ) else darkColorScheme(
        primary = c.accent, onPrimary = Color.White, background = c.bg, onBackground = c.text,
        surface = c.surface, onSurface = c.text, surfaceVariant = c.surface2, onSurfaceVariant = c.sec,
        outline = c.border, secondaryContainer = c.surface2, onSecondaryContainer = c.text
    )
    val d = LocalDensity.current
    val dens = Density(d.density, d.fontScale * S.fontScale.v / 100f)
    CompositionLocalProvider(LocalNova provides c, LocalDensity provides dens) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
