@file:OptIn(ExperimentalMaterial3Api::class, androidx.media3.common.util.UnstableApi::class)

package app.nova.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import app.nova.data.BannerCfg
import app.nova.data.Banners
import app.nova.data.LocalProfile
import app.nova.data.S
import app.nova.tg.*
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi
import java.io.File

/** Renders a banner config. `scroll` in px drives parallax / scale when cfg.parallax. */
@Composable
fun BannerView(cfg: BannerCfg, modifier: Modifier = Modifier, scroll: Float = 0f, fallbackTitle: String = "") {
    val c = Nova.c
    val ctx = LocalContext.current
    val fx = S.bannerParallax.v && cfg.parallax && !Motion.reduced
    val bright = cfg.brightness / 100f
    val cm = remember(bright) { ColorMatrix(floatArrayOf(bright, 0f, 0f, 0f, 0f, 0f, bright, 0f, 0f, 0f, 0f, 0f, bright, 0f, 0f, 0f, 0f, 0f, 1f, 0f)) }
    Box(modifier.clipToBounds().background(c.surface2)) {
        val layer = Modifier.fillMaxSize().graphicsLayer {
            val s = (cfg.scale / 100f) * (if (fx) (1f + (-scroll).coerceAtLeast(0f) / 1200f) else 1f)
            scaleX = s; scaleY = s
            translationY = if (fx) scroll * 0.5f else 0f
            transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, cfg.posY / 100f)
        }.let { if (cfg.blur > 0) it.blur(cfg.blur.dp) else it }
        when {
            cfg.kind == "gradient" -> {
                val t = rememberInfiniteTransition(label = "g")
                val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(Motion.ms(6000).coerceAtLeast(1), easing = LinearEasing), RepeatMode.Reverse), label = "gp")
                val a = if (cfg.animate && !Motion.reduced) p else 0.5f
                Box(layer.background(Brush.linearGradient(listOf(Color(cfg.g1), Color(cfg.g2)), start = androidx.compose.ui.geometry.Offset(1000f * a, 0f), end = androidx.compose.ui.geometry.Offset(1000f * (1 - a), 1200f))))
            }
            (cfg.kind == "image" || cfg.kind == "gif") && cfg.path.isNotEmpty() && File(cfg.path).exists() ->
                AsyncImage(File(cfg.path), null, layer, contentScale = ContentScale.Crop, alignment = Alignment.TopCenter, colorFilter = ColorFilter.colorMatrix(cm))
            cfg.kind == "video" && cfg.path.isNotEmpty() && File(cfg.path).exists() -> {
                val player = remember(cfg.path) {
                    ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(Uri.fromFile(File(cfg.path)))); repeatMode = Player.REPEAT_MODE_ALL; volume = 0f; prepare(); playWhenReady = true }
                }
                DisposableEffect(player) { onDispose { player.release() } }
                AndroidView({ PlayerView(it).apply { useController = false; this.player = player; resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM } }, layer.alpha(bright.coerceAtMost(1f)))
            }
            else -> Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(hashColor(fallbackTitle).copy(alpha = 0.7f), c.surface2))))
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = cfg.overlay / 100f)))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, c.bg.copy(alpha = 0.9f)), startY = 200f)))
    }
}

@Composable
fun ProfileScreen(r: Route.Profile, embedded: Boolean = false) {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val me by Tg.me.collectAsState()
    val isMe = me?.id == r.userId
    var user by remember { mutableStateOf(Tg.users[r.userId]) }
    var full by remember { mutableStateOf<TdApi.UserFullInfo?>(null) }
    var pinned by remember { mutableStateOf<Msg?>(null) }
    var chatId by remember { mutableLongStateOf(r.chatId) }
    var media by remember { mutableStateOf<List<Msg>>(emptyList()) }
    var mediaType by remember { mutableStateOf("Photos") }
    val chats by Tg.chats.collectAsState()
    val bannerState = Banners.state(r.userId)
    val cfg = bannerState.value
    val scroll = rememberScrollState()
    val density = androidx.compose.ui.platform.LocalDensity.current
    val fx = S.bannerParallax.v && !Motion.reduced
    val sPx = scroll.value.toFloat()
    val headerAlpha = if (fx) (sPx / 400f).coerceIn(0f, 1f) else 0f
    val avScale = if (fx) (1f - sPx / 900f).coerceIn(0.55f, 1f) else 1f

    LaunchedEffect(r.userId) {
        user = Tg.user(r.userId)
        try { val g = TdApi.GetUserFullInfo(); g.userId = r.userId; full = Tg.call(g) as TdApi.UserFullInfo } catch (e: Exception) { }
        if (chatId == 0L) chatId = Tg.openPrivate(r.userId) ?: 0L
    }
    LaunchedEffect(chatId, mediaType) {
        if (chatId != 0L) { media = Tg.mediaOf(chatId, mediaType); if (pinned == null) pinned = Tg.pinnedMessage(chatId) }
    }
    val u = user
    val name = u?.let { (it.firstName + " " + it.lastName).trim() } ?: ""

    Box(Modifier.fillMaxSize().background(c.bg)) {
        Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
            Box(Modifier.fillMaxWidth().height(if (S.profileStyle.v == "Compact") 120.dp else 240.dp)) {
                BannerView(cfg, Modifier.fillMaxSize(), scroll = -sPx, fallbackTitle = name)
            }
            Column(Modifier.fillMaxWidth().offset(y = (-48).dp).padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.graphicsLayer { scaleX = avScale; scaleY = avScale }.then(if (S.avatarRing.v) Modifier.border(3.dp, c.accent, shapeFor(S.avatarFrame.v)) else Modifier.border(3.dp, c.bg, shapeFor(S.avatarFrame.v)))
                ) { Avatar(u?.profilePhoto?.big?.id ?: u?.profilePhoto?.small?.id ?: 0, name.ifEmpty { "?" }, 104.dp, shapeFor(S.avatarFrame.v)) }
                Spacer(Modifier.height(10.dp))
                Text(name, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                val un = u?.usernames?.activeUsernames?.firstOrNull()
                if (un != null) Text("@$un", color = c.accent, fontSize = 15.sp)
                Text(u?.let { Tg.statusText(it) } ?: "", color = c.sec, fontSize = 13.sp)
                if (isMe && LocalProfile.status.value.isNotBlank()) Text(LocalProfile.status.value, color = c.text, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(50)).background(c.surface2).padding(horizontal = 12.dp, vertical = 4.dp))
                if (isMe && S.showBadges.v && LocalProfile.badges.value.isNotBlank()) Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LocalProfile.badges.value.split(",", " ").filter { it.isNotBlank() }.forEach { Text(it, fontSize = 20.sp) }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!isMe) ProfileBtn("Message", Icons.Filled.Chat) { if (chatId != 0L) Nav.openChat(chatId) }
                    if (isMe) { ProfileBtn("Edit", Icons.Filled.Edit) { Nav.push(Route.EditProfile) }; ProfileBtn("Banner", Icons.Filled.Image) { Nav.push(Route.BannerEditor(r.userId)) } }
                    else ProfileBtn("Banner", Icons.Filled.Image) { Nav.push(Route.BannerEditor(r.userId)) }
                    if (isMe) ProfileBtn("Saved", Icons.Filled.Bookmark) { scope.launch { Tg.savedMessagesId()?.let { Nav.openChat(it) } } }
                }
            }
            Column(Modifier.offset(y = (-32).dp)) {
                val bio = full?.bio?.text ?: ""
                if (bio.isNotBlank()) InfoRow("Bio", bio)
                if (u != null && u.phoneNumber.isNotBlank()) InfoRow("Phone", "+" + u.phoneNumber)
                if (isMe && S.showMusic.v && LocalProfile.music.value.isNotBlank()) InfoRow("Music", "🎵 " + LocalProfile.music.value)
                if (isMe && S.showLinks.v && LocalProfile.links.value.isNotBlank()) LocalProfile.links.value.lines().filter { it.isNotBlank() }.forEach { l ->
                    InfoRow("Link", l, accent = true) { try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(if (l.contains("://")) l else "https://$l")).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } }
                }
                if (isMe && S.showStats.v) {
                    val mine = chats.filter { !it.archived }
                    InfoRow("Statistics", "${mine.size} chats · ${mine.sumOf { it.unread }} unread · ${mine.count { it.kind == Kind.GROUP }} groups · ${mine.count { it.kind == Kind.CHANNEL }} channels · ${mine.count { it.pinned }} pinned")
                }
                if (S.showPinned.v) pinned?.let { InfoRow("Pinned message", it.text.ifBlank { Tg.kindLabel(it.kind) }) { Nav.openChat(chatId, it.id) } }

                SectionLabel("Shared media")
                Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Photos", "Videos", "Documents", "GIFs", "Voice").forEach { t -> FolderChip(t, mediaType == t, null) { mediaType = t } }
                }
                Spacer(Modifier.height(8.dp))
                val cols = if (S.mediaGrid.v.startsWith("4")) 4 else 3
                val rows = (media.size + cols - 1) / cols
                if (mediaType == "Photos" || mediaType == "Videos" || mediaType == "GIFs") {
                    Column(Modifier.padding(horizontal = 2.dp)) {
                        media.chunked(cols).forEach { row ->
                            Row { row.forEach { m -> Box(Modifier.weight(1f).aspectRatio(1f).padding(1.dp).background(c.surface2).clickable { Nav.push(Route.Media(chatId, m.id)) }) { MediaThumb(m) } }; repeat(cols - row.size) { Spacer(Modifier.weight(1f)) } }
                        }
                    }
                } else media.forEach { m ->
                    Row(Modifier.fillMaxWidth().clickable { Nav.openChat(chatId, m.id) }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text(if (m.kind == MKind.VOICE) "🎤 ${fmtDur(m.dur)}" else "📎 ${m.fileName.ifBlank { "File" }} · ${fmtSize(m.fileSize)}", color = c.text, fontSize = 14.sp)
                    }
                }
                if (media.isEmpty()) Text("Nothing here yet", color = c.sec, modifier = Modifier.padding(16.dp))
                Spacer(Modifier.height(80.dp))
            }
        }
        // collapsing header
        if (!embedded || true) Row(Modifier.fillMaxWidth().height(56.dp).background(c.surface.copy(alpha = headerAlpha)), verticalAlignment = Alignment.CenterVertically) {
            if (!embedded) IconButton(Nav::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = c.text) }
            Text(name, color = c.text.copy(alpha = headerAlpha), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = if (embedded) 16.dp else 0.dp))
        }
    }
}

@Composable
fun MediaThumb(m: Msg) {
    var p by remember(m.fileId) { mutableStateOf<String?>(null) }
    LaunchedEffect(m.fileId) { p = if (m.fileId != 0) Tg.download(m.fileId, priority = 2) else null }
    if (p != null && m.kind != MKind.VIDEO) AsyncImage(File(p!!), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (m.kind == MKind.VIDEO) "▶" else "…", color = Nova.c.sec, fontSize = 22.sp) }
}

@Composable
fun ProfileBtn(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    val c = Nova.c
    Column(Modifier.clip(RoundedCornerShape(14.dp)).background(c.surface2).springClick(null, onClick).padding(horizontal = 18.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = c.accent); Text(label, color = c.text, fontSize = 12.sp)
    }
}

@Composable
fun InfoRow(label: String, value: String, accent: Boolean = false, onClick: (() -> Unit)? = null) {
    val c = Nova.c
    Column(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(value, color = if (accent) c.accent else c.text, fontSize = 15.sp)
        Text(label, color = c.sec, fontSize = 12.sp)
    }
}

// ------------------------------------------------------------------ edit profile

@Composable
fun EditProfileScreen() {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val me by Tg.me.collectAsState()
    var first by remember { mutableStateOf(me?.firstName ?: "") }
    var last by remember { mutableStateOf(me?.lastName ?: "") }
    var bio by remember { mutableStateOf("") }
    var username by remember { mutableStateOf(me?.usernames?.activeUsernames?.firstOrNull() ?: "") }
    var status by remember { mutableStateOf(LocalProfile.status.value) }
    var music by remember { mutableStateOf(LocalProfile.music.value) }
    var links by remember { mutableStateOf(LocalProfile.links.value) }
    var badges by remember { mutableStateOf(LocalProfile.badges.value) }
    var msg by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { try { val g = TdApi.GetUserFullInfo(); g.userId = me?.id ?: 0; bio = (Tg.call(g) as TdApi.UserFullInfo).bio?.text ?: "" } catch (e: Exception) { } }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) scope.launch { copyToCache(ctx, u)?.let { try { Tg.setProfilePhoto(it); msg = "Photo updated" } catch (e: Exception) { msg = e.message ?: "Error" } } }
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("Edit profile") {
            TextButton({
                scope.launch {
                    try {
                        if (first != me?.firstName || last != me?.lastName) Tg.setName(first, last)
                        Tg.setBio(bio)
                        val old = me?.usernames?.activeUsernames?.firstOrNull() ?: ""
                        if (username != old) Tg.setUsername(username)
                        LocalProfile.save(status, music, links, badges)
                        Nav.pop()
                    } catch (e: Exception) { msg = e.message ?: "Error" }
                }
            }) { Text("Save", color = c.accent) }
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionRow("Change profile photo", icon = Icons.Filled.PhotoCamera) { pick.launch("image/*") }
            NField(first, { first = it }, "First name"); NField(last, { last = it }, "Last name")
            NField(bio, { bio = it }, "Bio (Telegram)"); NField(username, { username = it.removePrefix("@") }, "Username")
            SectionLabel("Local profile (shown only in this app)")
            NField(status, { status = it }, "Status line"); NField(music, { music = it }, "Music"); NField(badges, { badges = it }, "Badges (emoji)")
            OutlinedTextField(links, { links = it }, label = { Text("Links (one per line)") }, modifier = Modifier.fillMaxWidth(), minLines = 2, textStyle = androidx.compose.ui.text.TextStyle(color = c.text))
            if (msg.isNotEmpty()) Text(msg, color = c.sec)
        }
    }
}

// ------------------------------------------------------------------ banner editor

@Composable
fun BannerEditorScreen(userId: Long) {
    val c = Nova.c
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(Banners.state(userId).value) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) Banners.importMedia(ctx, u, userId)?.let { (p, k) -> cfg = cfg.copy(path = p, kind = k) }
    }
    val name = Tg.userName(userId)
    Column(Modifier.fillMaxSize()) {
        TopBar("Banner editor") { TextButton({ Banners.save(userId, cfg); Nav.pop() }) { Text("SAVE", color = c.accent) } }
        Box(Modifier.fillMaxWidth().height(220.dp)) {
            BannerView(cfg, Modifier.fillMaxSize(), fallbackTitle = name)
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp).size(72.dp).clip(CircleShape).border(2.dp, c.accent, CircleShape).background(hashColor(name)), contentAlignment = Alignment.Center) { Text(name.take(1), color = Color.White, fontSize = 28.sp) }
        }
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FolderChip("Pick photo / GIF / video", false, null) { pick.launch("*/*") }
                FolderChip("Gradient", cfg.kind == "gradient", null) { cfg = cfg.copy(kind = "gradient") }
                FolderChip("None", cfg.kind == "none", null) { cfg = cfg.copy(kind = "none", path = "") }
            }
            if (cfg.kind == "gradient") {
                var c1 by remember { mutableStateOf(false) }; var c2 by remember { mutableStateOf(false) }
                Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FolderChip("Colour 1", false, null) { c1 = true }; FolderChip("Colour 2", false, null) { c2 = true }
                }
                if (c1) ColorDialog("Colour 1", Color(cfg.g1), { c1 = false }) { cfg = cfg.copy(g1 = app.nova.data.argbOf(it)); c1 = false }
                if (c2) ColorDialog("Colour 2", Color(cfg.g2), { c2 = false }) { cfg = cfg.copy(g2 = app.nova.data.argbOf(it)); c2 = false }
            }
            BSlider("Position", cfg.posY, 0, 100, "%") { cfg = cfg.copy(posY = it) }
            BSlider("Scale", cfg.scale, 100, 250, "%") { cfg = cfg.copy(scale = it) }
            BSlider("Blur", cfg.blur, 0, 25, "dp") { cfg = cfg.copy(blur = it) }
            BSlider("Brightness", cfg.brightness, 20, 150, "%") { cfg = cfg.copy(brightness = it) }
            BSlider("Overlay", cfg.overlay, 0, 90, "%") { cfg = cfg.copy(overlay = it) }
            ToggleRow("Parallax", cfg.parallax) { cfg = cfg.copy(parallax = it) }
            ToggleRow("Animation (gradient)", cfg.animate) { cfg = cfg.copy(animate = it) }
            Text("Banners are stored on this device and are visible only to you in this app. Telegram has no public API for banners from third-party clients.", color = c.sec, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
        }
    }
}

@Composable
fun BSlider(title: String, v: Int, min: Int, max: Int, unit: String, onChange: (Int) -> Unit) {
    val c = Nova.c
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Row { Text(title, color = c.text, modifier = Modifier.weight(1f)); Text("$v$unit", color = c.accent) }
        Slider(v.toFloat(), { onChange(it.toInt()) }, valueRange = min.toFloat()..max.toFloat(), colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.surface2))
    }
}

@Composable
fun ToggleRow(title: String, v: Boolean, onChange: (Boolean) -> Unit) {
    val c = Nova.c
    Row(Modifier.fillMaxWidth().clickable { onChange(!v) }.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, modifier = Modifier.weight(1f))
        Switch(v, onChange, colors = SwitchDefaults.colors(checkedTrackColor = c.accent, checkedThumbColor = Color.White))
    }
}
