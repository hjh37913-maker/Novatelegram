@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package app.nova.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nova.data.LocalHistory
import app.nova.data.S
import app.nova.tg.*
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi
import java.io.File
import kotlin.math.roundToInt

private fun styled(m: Msg, linkColor: Color, revealed: Set<Int>): AnnotatedString = buildAnnotatedString {
    append(m.text)
    m.ents.forEachIndexed { i, e ->
        val s = e.off.coerceIn(0, m.text.length); val en = (e.off + e.len).coerceIn(s, m.text.length)
        when (e.t) {
            'b' -> addStyle(SpanStyle(fontWeight = FontWeight.Bold), s, en)
            'i' -> addStyle(SpanStyle(fontStyle = FontStyle.Italic), s, en)
            'u' -> addStyle(SpanStyle(textDecoration = TextDecoration.Underline), s, en)
            's' -> addStyle(SpanStyle(textDecoration = TextDecoration.LineThrough), s, en)
            'c' -> addStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x33888888)), s, en)
            'p' -> if (i !in revealed) addStyle(SpanStyle(color = Color.Transparent, background = Color(0xFF55596A)), s, en)
            'l' -> { addStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline), s, en); addStringAnnotation("url", e.url ?: "", s, en) }
        }
    }
}

@Composable
fun ChatScreen(r: Route.Chat) {
    val c = Nova.c
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val chatId = r.id
    var chat by remember { mutableStateOf(Tg.chatCache[chatId]) }
    var sub by remember { mutableStateOf("") }
    val msgs = remember { mutableStateListOf<Msg>() }          // newest first
    var loading by remember { mutableStateOf(false) }
    var endReached by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<Msg?>(null) }
    var editing by remember { mutableStateOf<Msg?>(null) }
    val sel = remember { mutableStateListOf<Long>() }
    var menuMsg by remember { mutableStateOf<Msg?>(null) }
    var historyOf by remember { mutableStateOf<Msg?>(null) }
    var translated by remember { mutableStateOf<String?>(null) }
    var pinned by remember { mutableStateOf<Msg?>(null) }
    var confirmDel by remember { mutableStateOf<List<Long>?>(null) }
    var showAttach by remember { mutableStateOf(false) }
    var lastTyping by remember { mutableLongStateOf(0L) }
    val state = rememberLazyListState()
    val tick = remember { mutableIntStateOf(0) }

    val deleted = remember(tick.intValue) { LocalHistory.deletedFor(chatId) }

    suspend fun loadMore(initial: Boolean) {
        if (loading || endReached) return
        loading = true
        try {
            val from = if (initial) (r.jumpTo) else (msgs.lastOrNull()?.id ?: 0L)
            val offset = if (initial && r.jumpTo != 0L) -20 else 0
            var list = Tg.history(chatId, from, offset, 40)
            if (list.isEmpty() && initial) { delay(400); list = Tg.history(chatId, 0, 0, 40) }
            if (list.isEmpty()) endReached = true
            val have = msgs.map { it.id }.toSet()
            list.filter { it.id !in have }.forEach { msgs.add(it) }
            msgs.sortByDescending { it.id }
        } catch (e: Exception) { }
        loading = false
    }

    fun refresh(id: Long) {
        val raw = Tg.rawMsg(chatId, id) ?: return
        val i = msgs.indexOfFirst { it.id == id }
        if (i >= 0) msgs[i] = Tg.toMsg(raw)
    }

    LaunchedEffect(chatId) {
        chat = Tg.chat(chatId)
        Tg.openChat = chatId
        app.nova.service.Notifier.clear(ctx, chatId)
        chat?.let { sub = Tg.subtitle(it) }
        val o = TdApi.OpenChat(); o.chatId = chatId; Tg.fire(o)
        loadMore(true)
        pinned = Tg.pinnedMessage(chatId)
        if (r.jumpTo != 0L) { val i = msgs.indexOfFirst { it.id == r.jumpTo }; if (i >= 0) state.scrollToItem(i) }
    }
    DisposableEffect2(chatId) { val cl = TdApi.CloseChat(); cl.chatId = chatId; Tg.fire(cl); Tg.openChat = 0L }

    LaunchedEffect(chatId) {
        Tg.events.collect { ev ->
            when (ev) {
                is TdApi.UpdateNewMessage -> if (ev.message.chatId == chatId && msgs.none { it.id == ev.message.id }) {
                    msgs.add(0, Tg.toMsg(ev.message))
                    if (S.autoRead.v && !ev.message.isOutgoing && Tg.foreground) Tg.markRead(chatId, listOf(ev.message.id))
                }
                is TdApi.UpdateMessageSendSucceeded -> if (ev.message.chatId == chatId) {
                    val i = msgs.indexOfFirst { it.id == ev.oldMessageId }
                    if (i >= 0) msgs[i] = Tg.toMsg(ev.message) else if (msgs.none { it.id == ev.message.id }) msgs.add(0, Tg.toMsg(ev.message))
                    msgs.sortByDescending { it.id }
                }
                is TdApi.UpdateMessageContent -> if (ev.chatId == chatId) { delay(30); refresh(ev.messageId) }
                is TdApi.UpdateMessageEdited -> if (ev.chatId == chatId) refresh(ev.messageId)
                is TdApi.UpdateMessageInteractionInfo -> if (ev.chatId == chatId) refresh(ev.messageId)
                is TdApi.UpdateDeleteMessages -> if (ev.chatId == chatId && ev.isPermanent) { delay(50); msgs.removeAll { it.id in ev.messageIds.toSet() }; tick.intValue++ }
                is TdApi.UpdateChatReadOutbox -> if (ev.chatId == chatId) tick.intValue++
                else -> {}
            }
        }
    }
    // mark read when open
    LaunchedEffect(msgs.firstOrNull()?.id, S.autoRead.v) {
        if (S.autoRead.v) {
            val unread = msgs.filter { !it.out }.take(1).map { it.id }
            if (unread.isNotEmpty() && Tg.foreground) Tg.markRead(chatId, unread)
        }
    }
    LaunchedEffect(state.firstVisibleItemIndex, msgs.size) {
        if (msgs.isNotEmpty() && state.firstVisibleItemIndex + state.layoutInfo.visibleItemsInfo.size >= msgs.size - 4) loadMore(false)
    }

    // pickers
    val photoPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) scope.launch { copyToCache(ctx, u)?.let { Tg.sendPhoto(chatId, it, input.also { input = "" }, replyTo?.id ?: 0); replyTo = null } }
    }
    val filePick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) scope.launch { copyToCache(ctx, u)?.let { Tg.sendFile(chatId, it, input.also { input = "" }, replyTo?.id ?: 0); replyTo = null } }
    }

    val rev = remember { mutableStateMapOf<Long, Set<Int>>() }
    val nameOf: (Long) -> String = { Tg.userName(it) }
    val isGroup = chat?.type.let { it is TdApi.ChatTypeBasicGroup || (it is TdApi.ChatTypeSupergroup) }
    val canSend = chat?.permissions?.canSendBasicMessages != false && !((chat?.type as? TdApi.ChatTypeSupergroup)?.isChannel == true && chat?.permissions?.canSendBasicMessages == false)

    Column(Modifier.fillMaxSize().background(chatBackground())) {
        // ---- header
        if (sel.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().background(c.surface).height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ sel.clear() }) { Icon(Icons.Filled.Close, null, tint = c.text) }
                Text("${sel.size}", color = c.text, fontSize = 18.sp, modifier = Modifier.weight(1f))
                IconButton({
                    val t = msgs.filter { it.id in sel }.sortedBy { it.id }.joinToString("\n") { it.text }
                    clip.setText(AnnotatedString(t)); sel.clear()
                }) { Icon(Icons.Filled.ContentCopy, null, tint = c.icon) }
                IconButton({ Nav.push(Route.Forward(chatId, sel.toList().sorted())); sel.clear() }) { Icon(Icons.Filled.Share, null, tint = c.icon) }
                IconButton({ confirmDel = sel.toList() }) { Icon(Icons.Filled.Delete, null, tint = c.icon) }
            }
        } else {
            Row(Modifier.fillMaxWidth().background(c.surface).height(60.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(Nav::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = c.text) }
                Row(Modifier.weight(1f).springClick {
                    (chat?.type as? TdApi.ChatTypePrivate)?.let { Nav.push(Route.Profile(it.userId, chatId)) }
                }, verticalAlignment = Alignment.CenterVertically) {
                    Avatar(chat?.photo?.small?.id ?: 0, chat?.title ?: "?", 40.dp, shapeFor(S.avatarShape.v))
                    Column(Modifier.padding(start = 10.dp)) {
                        Text(chat?.title ?: "", color = c.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(sub, color = c.sec, fontSize = 12.sp, maxLines = 1)
                    }
                }
                IconButton({ Nav.push(Route.Search(chatId)) }) { Icon(Icons.Filled.Search, null, tint = c.icon) }
            }
        }
        // pinned
        pinned?.let { p ->
            Row(Modifier.fillMaxWidth().background(c.surface2).clickable { scope.launch { val i = msgs.indexOfFirst { it.id == p.id }; if (i >= 0) state.animateScrollToItem(i) else { msgs.clear(); endReached = false; Nav.pop(); Nav.openChat(chatId, p.id) } } }.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(3.dp).height(30.dp).background(c.accent))
                Column(Modifier.padding(start = 8.dp).weight(1f)) {
                    Text("Pinned message", color = c.accent, fontSize = 12.sp)
                    Text(p.text.ifBlank { Tg.kindLabel(p.kind) }, color = c.text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        // ---- messages
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(Modifier.fillMaxSize(), state = state, reverseLayout = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)) {
                itemsIndexed(msgs, key = { _, m -> m.id }) { i, m ->
                    val older = msgs.getOrNull(i + 1)
                    val showDay = older == null || dayKey(older.date) != dayKey(m.date)
                    val prevSame = older != null && older.senderId == m.senderId && older.out == m.out && !showDay
                    val readOut = (chat?.lastReadOutboxMessageId ?: 0L) >= m.id
                    // deleted msgs placed right after the newer message that follows them
                    Column(Modifier.fillMaxWidth().animateItemCompat()) {
                        // reversed layout: later in the column = visually above
                        MessageBubble(
                            m, selected = m.id in sel, group = isGroup, showName = isGroup && !m.out && !prevSame, readOut = readOut,
                            revealed = rev[m.id] ?: emptySet(), nameOf = nameOf,
                            onReveal = { idx -> rev[m.id] = (rev[m.id] ?: emptySet()) + idx },
                            onTap = { if (sel.isNotEmpty()) { if (m.id in sel) sel.remove(m.id) else sel.add(m.id) } },
                            onLong = { if (sel.isEmpty()) menuMsg = m },
                            onDouble = { if (S.doubleTapReact.v) scope.launch { try { Tg.react(chatId, m.id, S.quickReaction.v, S.quickReaction.v in m.mine) } catch (e: Exception) { } } },
                            onReply = { if (S.swipeReply.v) replyTo = m },
                            onReact = { e -> scope.launch { try { Tg.react(chatId, m.id, e, e in m.mine) } catch (ex: Exception) { } } },
                            onOpenMedia = { Nav.push(Route.Media(chatId, m.id)) },
                            onReplyJump = { id -> scope.launch { val j = msgs.indexOfFirst { it.id == id }; if (j >= 0) state.animateScrollToItem(j) } },
                            onEditsShow = { historyOf = m }
                        )
                        deleted.filter { d -> d.id < m.id && (older == null || d.id > older.id) }.forEach { d -> DeletedBubble(d) }
                        if (showDay) Text(fmtDay(m.date), color = c.sec, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 8.dp).clip(RoundedCornerShape(50)).background(c.surface2.copy(alpha = 0.8f)).padding(horizontal = 12.dp, vertical = 3.dp))
                    }
                    Spacer(Modifier.height(if (prevSame) (S.msgSpacing.v / 2).dp else S.msgSpacing.v.dp + 2.dp))
                }
                if (loading) item { Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(22.dp), color = c.accent, strokeWidth = 2.dp) } }
            }
            AnimatedVisibility(state.firstVisibleItemIndex > 3, Modifier.align(Alignment.BottomEnd).padding(12.dp), enter = fadeIn(tween(Motion.ms(150)))) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(c.surface2).clickable { scope.launch { state.animateScrollToItem(0) } }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.KeyboardArrowDown, null, tint = c.text)
                }
            }
        }

        // ---- input
        if (canSend && sel.isEmpty()) {
            if (replyTo != null || editing != null) {
                Row(Modifier.fillMaxWidth().background(c.surface).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (editing != null) Icons.Filled.Edit else Icons.Filled.Reply, null, tint = c.accent)
                    Column(Modifier.padding(start = 8.dp).weight(1f)) {
                        Text(if (editing != null) "Editing" else "Reply to ${nameOf(replyTo!!.senderId)}", color = c.accent, fontSize = 12.sp)
                        Text((editing ?: replyTo)!!.text.ifBlank { Tg.kindLabel((editing ?: replyTo)!!.kind) }, color = c.sec, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton({ replyTo = null; editing = null; input = "" }) { Icon(Icons.Filled.Close, null, tint = c.sec) }
                }
            }
            Row(Modifier.fillMaxWidth().background(c.surface).padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.Bottom) {
                Box {
                    IconButton({ showAttach = true }) { Icon(Icons.Filled.AttachFile, null, tint = c.icon) }
                    DropdownMenu(showAttach, { showAttach = false }, containerColor = c.surface2) {
                        DropdownMenuItem({ Text("Photo", color = c.text) }, { showAttach = false; photoPick.launch("image/*") })
                        DropdownMenuItem({ Text("File", color = c.text) }, { showAttach = false; filePick.launch("*/*") })
                    }
                }
                OutlinedTextField(
                    input, {
                        input = it
                        val now = System.currentTimeMillis()
                        if (it.isNotEmpty() && now - lastTyping > 4000) { lastTyping = now; Tg.sendTyping(chatId) }
                    },
                    placeholder = { Text("Message", color = c.sec) }, maxLines = 6, modifier = Modifier.weight(1f),
                    textStyle = TextStyle(color = c.text, fontSize = 16.sp),
                    shape = RoundedCornerShape(22.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = c.border, unfocusedBorderColor = c.border, cursorColor = c.accent, focusedContainerColor = c.surface2, unfocusedContainerColor = c.surface2)
                )
                IconButton(
                    enabled = input.isNotBlank(),
                    onClick = {
                        val t = input.trim(); val e = editing; val rp = replyTo
                        input = ""; editing = null; replyTo = null
                        scope.launch {
                            try {
                                if (e != null) Tg.editText(chatId, e.id, t) else Tg.sendText(chatId, t, rp?.id ?: 0)
                                state.animateScrollToItem(0)
                            } catch (ex: Exception) { android.widget.Toast.makeText(ctx, ex.message ?: "Error", android.widget.Toast.LENGTH_SHORT).show() }
                        }
                    }
                ) { Icon(if (editing != null) Icons.Filled.Check else Icons.AutoMirrored.Filled.Send, null, tint = if (input.isNotBlank()) c.accent else c.sec) }
            }
        }
    }

    // ---- message menu
    menuMsg?.let { m ->
        val mine = m.out
        ModalBottomSheet({ menuMsg = null }, containerColor = c.surface) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                S.reactionSet.v.codePointsList().take(8).forEach { e ->
                    Text(e, fontSize = 28.sp, modifier = Modifier.clip(CircleShape).clickable { menuMsg = null; scope.launch { try { Tg.react(chatId, m.id, e, e in m.mine) } catch (ex: Exception) { } } }.padding(6.dp))
                }
            }
            Divider()
            ActionRow("Reply", icon = Icons.Filled.Reply) { replyTo = m; menuMsg = null }
            if (m.text.isNotBlank()) ActionRow("Copy text", icon = Icons.Filled.ContentCopy) { clip.setText(AnnotatedString(m.text)); menuMsg = null }
            if (m.text.isNotBlank()) ActionRow("Translate", icon = Icons.Filled.Translate) {
                menuMsg = null
                scope.launch { translated = try { Tg.translate(m.text, java.util.Locale.getDefault().language) } catch (e: Exception) { "Translation unavailable: ${e.message}" } }
            }
            if (mine && m.kind == MKind.TEXT) ActionRow("Edit", icon = Icons.Filled.Edit) { editing = m; input = m.text; menuMsg = null }
            if (LocalHistory.editsFor(chatId, m.id).isNotEmpty()) ActionRow("Edit history", icon = Icons.Filled.History) { historyOf = m; menuMsg = null }
            ActionRow("Forward", icon = Icons.Filled.Share) { Nav.push(Route.Forward(chatId, listOf(m.id))); menuMsg = null }
            ActionRow("Pin", icon = Icons.Filled.PushPin) { menuMsg = null; scope.launch { try { Tg.pin(chatId, m.id); pinned = m } catch (e: Exception) { } } }
            ActionRow("Select", icon = Icons.Filled.CheckCircle) { sel.add(m.id); menuMsg = null }
            if (m.fileId != 0 && m.kind == MKind.FILE) ActionRow("Save to Downloads", icon = Icons.Filled.Download) { menuMsg = null; scope.launch { Tg.download(m.fileId, m.fileName.ifBlank { "file" }) } }
            ActionRow("Delete", icon = Icons.Filled.Delete, danger = true) { confirmDel = listOf(m.id); menuMsg = null }
            Spacer(Modifier.height(24.dp))
        }
    }

    historyOf?.let { m ->
        val list = LocalHistory.editsFor(chatId, m.id)
        AlertDialog({ historyOf = null }, containerColor = c.surface2, title = { Text("Previous versions", color = c.text) },
            text = { Column { list.reversed().forEach { Text(it, color = c.text, modifier = Modifier.padding(vertical = 6.dp)); Divider() }; if (list.isEmpty()) Text("No saved edits", color = c.sec) } },
            confirmButton = { TextButton({ historyOf = null }) { Text("Close", color = c.accent) } })
    }

    translated?.let { t ->
        AlertDialog({ translated = null }, containerColor = c.surface2, title = { Text("Translation", color = c.text) }, text = { Text(t, color = c.text) },
            confirmButton = { TextButton({ translated = null }) { Text("Close", color = c.accent) } })
    }

    confirmDel?.let { ids ->
        val all = msgs.filter { it.id in ids }
        val canRevoke = all.all { it.out } || chat?.canBeDeletedForAllUsers == true
        val doDelete: (Boolean) -> Unit = { forAll -> confirmDel = null; sel.clear(); scope.launch { try { Tg.deleteMessages(chatId, ids, forAll); msgs.removeAll { it.id in ids } } catch (e: Exception) { } } }
        if (!S.confirmDelete.v) { LaunchedEffect(ids) { doDelete(S.deleteForAll.v && canRevoke) } }
        else AlertDialog({ confirmDel = null }, containerColor = c.surface2, title = { Text("Delete ${ids.size} message(s)?", color = c.text) },
            confirmButton = { if (canRevoke) TextButton({ doDelete(true) }) { Text("Delete for everyone", color = Color(0xFFFF5C5C)) } },
            dismissButton = { Row { TextButton({ doDelete(false) }) { Text("Delete for me", color = Color(0xFFFF5C5C)) }; TextButton({ confirmDel = null }) { Text("Cancel", color = c.sec) } } })
    }
}

@Composable
private fun DisposableEffect2(key: Any?, onDispose: () -> Unit) {
    androidx.compose.runtime.DisposableEffect(key) { onDispose { onDispose() } }
}

private fun Modifier.animateItemCompat(): Modifier = this

private fun String.codePointsList(): List<String> {
    val out = ArrayList<String>(); var i = 0
    while (i < length) { val cp = codePointAt(i); val n = Character.charCount(cp); out.add(substring(i, i + n)); i += n }
    return out
}

fun copyToCache(ctx: android.content.Context, uri: Uri): String? = try {
    val name = (ctx.contentResolver.query(uri, null, null, null, null)?.use { cu -> if (cu.moveToFirst()) cu.getString(cu.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME)) else null }) ?: "file"
    val dir = File(ctx.cacheDir, "up").apply { mkdirs() }
    val f = File(dir, System.currentTimeMillis().toString() + "_" + name)
    ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    f.absolutePath
} catch (e: Exception) { null }

@Composable
fun chatBackground(): Brush {
    val c = Nova.c
    return when (S.chatBgStyle.v) {
        "Solid" -> Brush.verticalGradient(listOf(S.chatBgColor.color, S.chatBgColor.color))
        "Gradient" -> Brush.verticalGradient(listOf(S.chatBgColor.color, S.chatBgColor2.color))
        else -> Brush.verticalGradient(listOf(c.bg, c.bg))
    }
}

@Composable
fun DeletedBubble(d: app.nova.data.DeletedMsg) {
    val c = Nova.c
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = if (d.out) Arrangement.End else Arrangement.Start) {
        Column(Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(S.bubbleRadius.v.dp)).border(1.dp, Color(0xFFFF5C5C).copy(alpha = 0.6f), RoundedCornerShape(S.bubbleRadius.v.dp)).padding(10.dp)) {
            Text(d.text, color = c.text.copy(alpha = 0.75f), fontSize = S.msgFontSize.v.sp)
            Text("deleted · ${fmtTime(d.date)}", color = Color(0xFFFF5C5C), fontSize = 11.sp)
        }
    }
}

@Composable
fun MessageBubble(
    m: Msg, selected: Boolean, group: Boolean, showName: Boolean, readOut: Boolean, revealed: Set<Int>,
    nameOf: (Long) -> String, onReveal: (Int) -> Unit, onTap: () -> Unit, onLong: () -> Unit, onDouble: () -> Unit,
    onReply: () -> Unit, onReact: (String) -> Unit, onOpenMedia: () -> Unit, onReplyJump: (Long) -> Unit, onEditsShow: () -> Unit
) {
    val c = Nova.c
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shape = RoundedCornerShape(S.bubbleRadius.v.dp)
    val bg = when (S.bubbleStyle.v) { "Outlined" -> Color.Transparent; "Flat" -> if (m.out) c.bubbleOut.copy(alpha = 0.55f) else c.bubbleIn.copy(alpha = 0.55f); else -> if (m.out) c.bubbleOut else c.bubbleIn }
    val borderC = if (S.bubbleStyle.v == "Outlined") (if (m.out) c.accent else c.border) else Color.Transparent
    var dx by remember { mutableFloatStateOf(0f) }
    var replied by remember { mutableStateOf<Msg?>(null) }
    LaunchedEffect(m.replyToId) { if (m.replyToId != 0L) replied = Tg.getMessage(m.chatId, m.replyToId) }
    val link = c.accent
    val showAv = group && S.groupAvatars.v && !m.out

    Row(
        Modifier.fillMaxWidth().offset { androidx.compose.ui.unit.IntOffset(dx.roundToInt(), 0) }
            .background(if (selected) c.accent.copy(alpha = 0.15f) else Color.Transparent)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(onDragEnd = { if (dx < -90f) onReply(); dx = 0f }, onDragCancel = { dx = 0f }) { _, d -> dx = (dx + d).coerceIn(-140f, 0f) }
            },
        horizontalArrangement = if (m.out) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom
    ) {
        if (showAv) { Avatar(Tg.users[m.senderId]?.profilePhoto?.small?.id ?: 0, nameOf(m.senderId).ifEmpty { "?" }, 30.dp); Spacer(Modifier.width(6.dp)) }
        else if (group && S.groupAvatars.v && !m.out) Spacer(Modifier.width(36.dp))
        Column(
            Modifier.widthIn(max = 320.dp).clip(shape).background(bg).border(1.dp, borderC, shape)
                .pointerInput(m.id) { detectTapGestures(onTap = { onTap() }, onLongPress = { onLong() }, onDoubleTap = { onDouble() }) }
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            if (showName && S.showSender.v) Text(nameOf(m.senderId), color = hashColor(nameOf(m.senderId)), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            if (m.fwd) Text("Forwarded", color = c.accent, fontSize = 12.sp)
            replied?.let { rp ->
                Row(Modifier.padding(bottom = 4.dp).clickable { onReplyJump(rp.id) }.height(IntrinsicSize.Min)) {
                    Box(Modifier.width(2.dp).fillMaxHeight().background(c.accent))
                    Column(Modifier.padding(start = 6.dp)) {
                        Text(nameOf(rp.senderId).ifEmpty { "Message" }, color = c.accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(rp.text.ifBlank { Tg.kindLabel(rp.kind) }, color = c.text.copy(alpha = 0.8f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            MediaPart(m, onOpenMedia)
            if (m.text.isNotEmpty() && m.kind != MKind.STICKER) {
                ClickableText(styled(m, link, revealed), style = TextStyle(color = c.text, fontSize = S.msgFontSize.v.sp)) { off ->
                    val a = styled(m, link, revealed)
                    a.getStringAnnotations("url", off, off).firstOrNull()?.let { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it.item)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } }
                        ?: run { m.ents.forEachIndexed { i, e -> if (e.t == 'p' && off in e.off until e.off + e.len) onReveal(i) } }
                }
            }
            if (m.reactions.isNotEmpty()) Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                m.reactions.forEach { (e, n) ->
                    Text("$e $n", fontSize = 13.sp, color = c.text, modifier = Modifier.clip(RoundedCornerShape(50)).background(if (e in m.mine) c.accent.copy(alpha = 0.5f) else c.surface2).clickable { onReact(e) }.padding(horizontal = 8.dp, vertical = 2.dp))
                }
            }
            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                if (S.showIds.v) Text("#${m.id}  ", color = c.sec, fontSize = 10.sp)
                if (m.edited) Text("edited ", color = c.sec, fontSize = 11.sp, modifier = Modifier.clickable { onEditsShow() })
                if (S.showTime.v) Text(fmtTime(m.date), color = c.sec.copy(alpha = 0.9f), fontSize = 11.sp)
                if (m.out && S.showTicks.v) Text(if (m.sending) " ◷" else if (readOut) " ✓✓" else " ✓", color = if (readOut) c.accent else c.sec, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun MediaPart(m: Msg, onOpen: () -> Unit) {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    if (m.fileId == 0 && m.kind != MKind.FILE && m.kind != MKind.VOICE) return
    val files by Tg.files.collectAsState()
    var path by remember(m.fileId) { mutableStateOf<String?>(null) }
    var wanted by remember(m.fileId) { mutableStateOf(false) }
    val auto = Tg.canAutoDownload(m.kind, m.fileSize)
    LaunchedEffect(m.fileId, auto) {
        if (m.fileId == 0) return@LaunchedEffect
        path = Tg.localPath(m.fileId)
        if (path == null && (auto || wanted)) path = Tg.download(m.fileId, m.fileName.ifBlank { Tg.kindLabel(m.kind) })
    }
    LaunchedEffect(wanted) { if (wanted && path == null) path = Tg.download(m.fileId, m.fileName.ifBlank { Tg.kindLabel(m.kind) }) }
    val ratio = if (m.w > 0 && m.h > 0) (m.w.toFloat() / m.h).coerceIn(0.5f, 2f) else 1.3f
    when (m.kind) {
        MKind.PHOTO, MKind.VIDEO, MKind.ANIM, MKind.STICKER -> {
            val w = if (m.kind == MKind.STICKER) 160.dp else 260.dp
            Box(Modifier.width(w).aspectRatio(ratio).clip(RoundedCornerShape(10.dp)).background(c.surface2).clickable { if (path != null) onOpen() else wanted = true }, contentAlignment = Alignment.Center) {
                if (path != null && m.kind != MKind.VIDEO) AsyncImage(File(path!!), null, Modifier.fillMaxSize(), contentScale = if (m.kind == MKind.STICKER) ContentScale.Fit else ContentScale.Crop)
                else if (path != null) { Text("▶", color = Color.White, fontSize = 36.sp) }
                else {
                    val fi = files[m.fileId]
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (wanted && fi != null && fi.size > 0) CircularProgressIndicator(progress = { fi.done.toFloat() / fi.size }, color = c.accent, modifier = Modifier.size(32.dp))
                        else Text("⬇ ${fmtSize(m.fileSize)}", color = c.text, fontSize = 13.sp)
                    }
                }
                if (m.kind == MKind.VIDEO && m.dur > 0) Text(fmtDur(m.dur), color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomStart).padding(6.dp).background(Color(0x88000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp))
            }
        }
        MKind.VOICE -> VoicePlayer(m, path) { wanted = true }
        MKind.FILE -> {
            val fi = files[m.fileId]
            Row(Modifier.padding(vertical = 2.dp).clickable {
                if (path == null) wanted = true else openFile(Tg.app, path!!)
            }, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(c.accent), contentAlignment = Alignment.Center) {
                    if (wanted && path == null && fi != null && fi.size > 0) CircularProgressIndicator(progress = { fi.done.toFloat() / fi.size }, color = Color.White, modifier = Modifier.size(30.dp), strokeWidth = 2.dp)
                    else Icon(if (path != null) Icons.Filled.InsertDriveFile else Icons.Filled.Download, null, tint = Color.White)
                }
                Column(Modifier.padding(start = 10.dp)) {
                    Text(m.fileName.ifBlank { "File" }, color = c.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(fmtSize(m.fileSize), color = c.sec, fontSize = 12.sp)
                }
            }
        }
        else -> {}
    }
}

fun openFile(ctx: android.content.Context, path: String) {
    try {
        val f = File(path)
        val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val ext = f.extension.lowercase()
        val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { android.widget.Toast.makeText(ctx, "No app can open this file", android.widget.Toast.LENGTH_SHORT).show() }
}

@Composable
fun VoicePlayer(m: Msg, path: String?, onNeed: () -> Unit) {
    val c = Nova.c
    var playing by remember { mutableStateOf(false) }
    var mp by remember { mutableStateOf<android.media.MediaPlayer?>(null) }
    DisposableEffect2(m.fileId) { mp?.release() }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(c.accent).clickable {
            if (path == null) { onNeed(); return@clickable }
            if (playing) { mp?.pause(); playing = false }
            else {
                if (mp == null) mp = android.media.MediaPlayer().apply { setDataSource(path); prepare(); setOnCompletionListener { playing = false; seekTo(0) } }
                mp?.start(); playing = true
            }
        }, contentAlignment = Alignment.Center) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White) }
        Text("  🎤 ${fmtDur(m.dur)}", color = c.text, fontSize = 14.sp)
    }
}
