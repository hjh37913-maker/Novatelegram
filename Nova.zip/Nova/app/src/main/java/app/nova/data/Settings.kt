package app.nova.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** Persistent, Compose-observable settings. Every setting here is wired to real behaviour. */
sealed class Setting(val key: String, val title: String, val desc: String) {
    abstract fun load(sp: SharedPreferences)
}

class BoolS(key: String, title: String, desc: String, val def: Boolean) : Setting(key, title, desc) {
    var v by mutableStateOf(def)
        private set
    override fun load(sp: SharedPreferences) { v = sp.getBoolean(key, def) }
    fun set(x: Boolean) { v = x; S.sp.edit().putBoolean(key, x).apply() }
}

class IntS(
    key: String, title: String, desc: String,
    val def: Int, val min: Int, val max: Int, val unit: String = ""
) : Setting(key, title, desc) {
    var v by mutableStateOf(def)
        private set
    override fun load(sp: SharedPreferences) { v = sp.getInt(key, def).coerceIn(min, max) }
    fun set(x: Int) { v = x.coerceIn(min, max); S.sp.edit().putInt(key, v).apply() }
}

class ChoiceS(
    key: String, title: String, desc: String,
    val options: List<String>, val def: String
) : Setting(key, title, desc) {
    var v by mutableStateOf(def)
        private set
    override fun load(sp: SharedPreferences) {
        val s = sp.getString(key, def) ?: def
        v = if (s in options) s else def
    }
    fun set(x: String) { v = x; S.sp.edit().putString(key, x).apply() }
}

class ColorS(key: String, title: String, desc: String, val def: Long) : Setting(key, title, desc) {
    var v by mutableStateOf(def)
        private set
    val color: Color get() = Color(v)
    override fun load(sp: SharedPreferences) { v = sp.getLong(key, def) }
    fun set(x: Long) { v = x; S.sp.edit().putLong(key, x).apply() }
    fun set(c: Color) { set(argbOf(c)) }
}

class TextS(key: String, title: String, desc: String, val def: String) : Setting(key, title, desc) {
    var v by mutableStateOf(def)
        private set
    override fun load(sp: SharedPreferences) { v = sp.getString(key, def) ?: def }
    fun set(x: String) { v = x; S.sp.edit().putString(key, x).apply() }
}

fun argbOf(c: Color): Long {
    val a = (c.alpha * 255f + 0.5f).toInt()
    val r = (c.red * 255f + 0.5f).toInt()
    val g = (c.green * 255f + 0.5f).toInt()
    val b = (c.blue * 255f + 0.5f).toInt()
    return ((a.toLong() shl 24) or (r.toLong() shl 16) or (g.toLong() shl 8) or b.toLong()) and 0xFFFFFFFFL
}

class Group(val title: String, val items: List<Setting>)

object S {
    val all = mutableListOf<Setting>()
    lateinit var sp: SharedPreferences

    private fun <T : Setting> r(s: T): T { all.add(s); return s }
    private fun b(k: String, t: String, d: String, def: Boolean) = r(BoolS(k, t, d, def))
    private fun i(k: String, t: String, d: String, def: Int, min: Int, max: Int, u: String = "") = r(IntS(k, t, d, def, min, max, u))
    private fun c(k: String, t: String, d: String, o: List<String>, def: String) = r(ChoiceS(k, t, d, o, def))
    private fun col(k: String, t: String, d: String, def: Long) = r(ColorS(k, t, d, def))
    private fun tx(k: String, t: String, d: String, def: String) = r(TextS(k, t, d, def))

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("nova_settings", Context.MODE_PRIVATE)
        all.forEach { it.load(sp) }
    }

    // ---- plain flags / strings (not shown in settings lists) ----
    fun flag(k: String, def: Boolean = false) = sp.getBoolean(k, def)
    fun setFlag(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun str(k: String, def: String = "") = sp.getString(k, def) ?: def
    fun setStr(k: String, v: String) { sp.edit().putString(k, v).apply() }

    // ================= Appearance / Theme =================
    val themeMode = c("themeMode", "Theme", "Base look of the whole app", listOf("Dark", "AMOLED", "Light", "Classic", "Custom"), "Dark")
    val followSystem = b("followSystem", "Follow system light/dark", "Dark ↔ Light automatically (Dark/Light modes only)", false)
    val accent = col("accent", "Accent colour", "Buttons, links, outgoing bubbles", 0xFF4C8DFFL)

    // ---- custom palette (used by Theme Editor / Custom mode) ----
    val cBg = col("c_bg", "Background", "", 0xFF08090DL)
    val cSurface = col("c_surface", "Surface", "", 0xFF111318L)
    val cSurface2 = col("c_surface2", "Surface 2", "", 0xFF171920L)
    val cText = col("c_text", "Text", "", 0xFFFFFFFFL)
    val cSec = col("c_sec", "Secondary text", "", 0xFF969AA5L)
    val cBubbleIn = col("c_bubble_in", "Incoming bubble", "", 0xFF171920L)
    val cBubbleOut = col("c_bubble_out", "Outgoing bubble", "", 0xFF2C5CB8L)
    val cBorder = col("c_border", "Border", "", 0xFF1F222BL)
    val cIcons = col("c_icons", "Icons", "", 0xFFC9CCD6L)
    val cNav = col("c_nav", "Navigation bar", "", 0xFF0D0F14L)

    // ---- chat appearance ----
    val bubbleStyle = c("bubbleStyle", "Bubble style", "Filled, outlined or flat", listOf("Filled", "Outlined", "Flat"), "Filled")
    val bubbleRadius = i("bubbleRadius", "Corner radius", "Message bubble corners", 18, 0, 28, "dp")
    val msgSpacing = i("msgSpacing", "Message spacing", "Gap between messages", 4, 0, 16, "dp")
    val msgFontSize = i("msgFontSize", "Message text size", "", 16, 12, 24, "sp")
    val fontScale = i("fontScale", "Interface font scale", "Scales all text in the app", 100, 80, 140, "%")
    val chatBgStyle = c("chatBgStyle", "Chat background", "", listOf("Theme", "Solid", "Gradient", "Image"), "Theme")
    val chatBgColor = col("chatBgColor", "Chat background colour", "Used by Solid / Gradient", 0xFF0B1220L)
    val chatBgColor2 = col("chatBgColor2", "Gradient second colour", "", 0xFF1B1030L)
    val chatBgImage = tx("chatBgImage", "Chat background image", "", "")
    val showTime = b("showTime", "Show message time", "", true)
    val time12h = b("time12h", "12-hour clock", "", false)
    val showSender = b("showSender", "Show sender names in groups", "", true)
    val groupAvatars = b("groupAvatars", "Show avatars in groups", "", true)
    val showTicks = b("showTicks", "Show delivery ticks", "", true)

    // ---- animations ----
    val animSpeed = i("animSpeed", "Animation speed", "100% = default, higher is faster", 100, 50, 250, "%")
    val reduced = b("reducedMotion", "Reduced motion", "Turns off transitions", false)
    val spring = b("springPress", "Spring on press", "Elements squish slightly when pressed", true)
    val msgAppear = b("msgAppear", "Animate new messages", "", true)
    val bannerParallax = b("bannerParallax", "Profile scroll effects", "Banner scale, avatar shrink, header fade", true)
    val batteryNoAnim = b("batteryNoAnim", "No animations in battery saver", "", true)

    // ---- navigation ----
    val navPreset = c(
        "navPreset", "Bottom tabs", "Which tabs and in which order",
        listOf("Chats · Contacts · Search · Settings", "Chats · Search · Profile · Settings", "Chats · Contacts · Profile · Settings", "Chats · Settings"),
        "Chats · Contacts · Search · Settings"
    )
    val navLabels = b("navLabels", "Tab labels", "", true)
    val swipeBack = b("swipeBack", "Swipe from left edge to go back", "", true)

    // ================= Chats =================
    val density = c("density", "Chat list density", "", listOf("Compact", "Normal", "Roomy"), "Normal")
    val showPreview = b("showPreview", "Message preview in list", "", true)
    val previewLines = i("previewLines", "Preview lines", "", 1, 1, 3)
    val avatarShape = c("avatarShape", "Avatar shape", "", listOf("Circle", "Squircle", "Square"), "Circle")
    val avatarSize = i("avatarSize", "Avatar size in list", "", 52, 36, 64, "dp")
    val sortMode = c("sortMode", "Sort chats", "", listOf("Telegram order", "Last activity", "Unread first", "By type"), "Telegram order")
    val pinnedFirst = b("pinnedFirst", "Keep pinned chats on top", "", true)
    val mutedGrey = b("mutedGrey", "Grey badge for muted chats", "", true)
    val folderChips = b("folderChips", "Show folder chips", "", true)
    val unreadOnly = b("unreadOnly", "Unread only mode", "Hide read chats in the list", false)
    val importantOnly = b("importantOnly", "Important only mode", "Hide muted chats", false)
    val swipeActions = b("swipeActions", "Swipe actions", "", true)
    val swipeRight = c("swipeRight", "Swipe right action", "", listOf("Read / Unread", "Pin / Unpin", "Archive", "Mute / Unmute"), "Read / Unread")
    val swipeLeft = c("swipeLeft", "Swipe left action", "", listOf("Read / Unread", "Pin / Unpin", "Archive", "Mute / Unmute"), "Archive")
    val smartArchive = b("smartArchive", "Smart archive hint", "Show a hint to archive chats idle for 30+ days", false)

    // ---- messages ----
    val keepDeleted = b("keepDeleted", "Keep deleted messages locally", "Messages deleted by others stay visible (only on this device)", true)
    val saveEdits = b("saveEdits", "Save edit history locally", "", true)
    val confirmDelete = b("confirmDelete", "Confirm before deleting", "", true)
    val deleteForAll = b("deleteForAll", "Delete for everyone by default", "", true)
    val quickReaction = tx("quickReaction", "Quick reaction", "Used by double-tap", "❤")
    val reactionSet = tx("reactionSet", "Reaction picker emoji", "Your own set for the picker", "❤👍🔥😂😮😢🎉🤔👎🙏💯👏")
    val doubleTapReact = b("doubleTapReact", "Double-tap to react", "", true)
    val swipeReply = b("swipeReply", "Swipe left to reply", "", true)
    val mdFormat = b("mdFormat", "Markdown-style formatting", "**bold** __italic__ `code` ~~strike~~ ||spoiler||", true)
    val sendOnEnter = b("sendOnEnter", "Enter key sends message", "", false)
    val localTtl = i("localTtl", "Delete local copies after", "Days to keep locally saved deleted/edited copies (0 = never)", 0, 0, 365, "d")

    // ---- media ----
    val autoPhoto = b("autoPhoto", "Auto-download photos", "", true)
    val autoVideo = b("autoVideo", "Auto-download videos", "", false)
    val autoMaxMb = i("autoMaxMb", "Auto-download size limit", "", 10, 1, 200, "MB")
    val autoWifiOnly = b("autoWifiOnly", "Only on Wi-Fi / unmetered", "", true)
    val lowData = b("lowData", "Low data mode", "Disables all auto-download", false)
    val mediaGrid = c("mediaGrid", "Shared media grid", "", listOf("3 columns", "4 columns"), "3 columns")

    // ================= Profile =================
    val showBadges = b("showBadges", "Show badges", "Local badges on your profile", true)
    val showMusic = b("showMusic", "Show music line", "", true)
    val showLinks = b("showLinks", "Show links", "", true)
    val showStats = b("showStats", "Show statistics", "Local counters (chats, unread, contacts)", true)
    val showPinned = b("showPinned", "Show pinned message", "", true)
    val avatarFrame = c("avatarFrame", "Profile avatar shape", "", listOf("Circle", "Squircle", "Square"), "Circle")
    val avatarRing = b("avatarRing", "Accent ring around avatar", "", true)
    val profileStyle = c("profileStyle", "Profile layout", "", listOf("Banner", "Compact"), "Banner")

    // ================= Privacy =================
    val appLock = b("appLock", "App lock", "Ask PIN / biometrics when opening", false)
    val biometric = b("biometric", "Biometric unlock", "", false)
    val autoLock = c("autoLock", "Auto-lock after", "", listOf("Immediately", "1 minute", "5 minutes", "1 hour"), "1 minute")
    val screenshotProt = b("screenshotProt", "Screenshot protection", "Blocks screenshots & hides the app in recents (FLAG_SECURE)", false)
    val privacyMode = b("privacyMode", "Privacy mode", "Hide previews in chat list until you tap", false)
    val stayOffline = b("stayOffline", "Stay offline while using the app", "Does not tell Telegram you are online (TDLib option)", false)
    val sendTyping = b("sendTyping", "Send typing indicator", "Turn off to type silently", true)
    val autoRead = b("autoRead", "Mark messages as read when chat is open", "Turn off to read without sending read receipts; use the ✓ button to mark read", true)
    val notifOn = b("notifOn", "Notifications", "", true)
    val notifHideText = b("notifHideText", "Hide text in notifications", "", false)
    val notifGroup = b("notifGroup", "Group notifications by chat", "", true)
    val notifPriority = b("notifPriority", "Priority by chat type", "Private chats loud, groups normal, channels quiet", true)

    // ================= Performance =================
    val keepAlive = b("keepAlive", "Background connection", "Foreground service keeps Telegram connected so notifications arrive", false)
    val autoClean = b("autoClean", "Auto-clean cache on start", "", false)
    val autoCleanDays = i("autoCleanDays", "Delete cached files older than", "", 14, 1, 90, "d")
    val imageCacheMb = i("imageCacheMb", "Image memory cache", "", 25, 5, 50, "%")

    // ================= Advanced =================
    val showIds = b("showIds", "Show message IDs", "", false)
    val debugOverlay = b("debugOverlay", "Debug info on chat list", "", false)
    val logLevel = c("logLevel", "TDLib log verbosity", "", listOf("0", "1", "2", "3", "4", "5"), "1")

    // ---- groups for settings pages ----
    val groups: Map<String, List<Group>> by lazy {
        mapOf(
            "appearance" to listOf(
                Group("Theme", listOf(themeMode, followSystem)),
                Group("Colors", listOf(accent)),
                Group("Chat appearance", listOf(bubbleStyle, bubbleRadius, msgSpacing, msgFontSize, fontScale, chatBgStyle, chatBgColor, chatBgColor2, showTime, time12h, showSender, groupAvatars, showTicks)),
                Group("Animations", listOf(animSpeed, reduced, spring, msgAppear, bannerParallax, batteryNoAnim)),
                Group("Navigation", listOf(navPreset, navLabels, swipeBack))
            ),
            "chats" to listOf(
                Group("Chat list", listOf(density, showPreview, previewLines, avatarShape, avatarSize, sortMode, pinnedFirst, mutedGrey, folderChips, unreadOnly, importantOnly, smartArchive)),
                Group("Messages", listOf(keepDeleted, saveEdits, confirmDelete, deleteForAll, quickReaction, reactionSet, mdFormat, sendOnEnter, localTtl)),
                Group("Media", listOf(autoPhoto, autoVideo, autoMaxMb, autoWifiOnly, lowData, mediaGrid)),
                Group("Gestures", listOf(swipeActions, swipeRight, swipeLeft, swipeReply, doubleTapReact))
            ),
            "profile" to listOf(
                Group("Avatar", listOf(avatarFrame, avatarRing)),
                Group("Customization", listOf(profileStyle, showBadges, showMusic, showLinks, showStats, showPinned))
            ),
            "privacy" to listOf(
                Group("Messages", listOf(stayOffline, sendTyping, autoRead)),
                Group("Notifications", listOf(notifOn, notifHideText, notifGroup, notifPriority)),
                Group("App lock", listOf(appLock, biometric, autoLock, screenshotProt, privacyMode))
            ),
            "performance" to listOf(
                Group("Cache", listOf(autoClean, autoCleanDays, imageCacheMb)),
                Group("Battery", listOf(keepAlive))
            ),
            "advanced" to listOf(
                Group("Experimental", listOf(showIds)),
                Group("Debug", listOf(debugOverlay, logLevel))
            )
        )
    }

    fun resetAppearance() {
        listOf<Setting>(
            themeMode, followSystem, accent, bubbleStyle, bubbleRadius, msgSpacing, msgFontSize, fontScale,
            chatBgStyle, animSpeed, reduced, density
        ).forEach { s ->
            sp.edit().remove(s.key).apply(); s.load(sp)
        }
    }
}
