package app.nova.tg

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import app.nova.data.DeletedMsg
import app.nova.data.LocalHistory
import app.nova.data.S
import app.nova.data.SecureKey
import app.nova.service.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.io.File
import java.util.Collections
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

class TdError(val code: Int, message: String) : Exception(message)

enum class Kind { PRIVATE, GROUP, CHANNEL, BOT, SECRET }
enum class MKind { TEXT, PHOTO, VIDEO, VOICE, FILE, STICKER, ANIM, OTHER }

data class Ent(val off: Int, val len: Int, val t: Char, val url: String?)

data class ChatRow(
    val id: Long, val title: String, val kind: Kind, val last: String, val lastDate: Int,
    val lastOut: Boolean, val unread: Int, val pinned: Boolean, val order: Long, val muted: Boolean,
    val archived: Boolean, val photoId: Int, val userId: Long, val lastMsgId: Long, val markedUnread: Boolean
)

data class Msg(
    val id: Long, val chatId: Long, val out: Boolean, val date: Int, val senderId: Long,
    val text: String, val ents: List<Ent>, val kind: MKind, val fileId: Int, val fileSize: Long,
    val fileName: String, val w: Int, val h: Int, val dur: Int, val replyToId: Long,
    val edited: Boolean, val fwd: Boolean, val reactions: List<Pair<String, Int>>,
    val mine: List<String> = emptyList(), val deleted: Boolean = false, val sending: Boolean = false
)

data class FileInfo(val id: Int, val name: String, val size: Long, val done: Long, val active: Boolean, val completed: Boolean, val path: String)

data class Hit(val msg: Msg, val chatTitle: String)

object Tg {
    lateinit var app: Context
    private var client: Client? = null
    private var started = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val auth = MutableStateFlow<TdApi.AuthorizationState?>(null)
    val conn = MutableStateFlow("Connecting…")
    val chats = MutableStateFlow<List<ChatRow>>(emptyList())
    val me = MutableStateFlow<TdApi.User?>(null)
    val files = MutableStateFlow<Map<Int, FileInfo>>(emptyMap())
    val events = MutableSharedFlow<TdApi.Object>(extraBufferCapacity = 512, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    val users = ConcurrentHashMap<Long, TdApi.User>()
    val chatCache = ConcurrentHashMap<Long, TdApi.Chat>()
    private val paths = ConcurrentHashMap<Int, String>()
    private val tracked = ConcurrentHashMap<Int, String>()
    private val selfDeleting = Collections.synchronizedSet(HashSet<String>())
    private val raw = Collections.synchronizedMap(object : LinkedHashMap<String, TdApi.Message>(512, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, TdApi.Message>?) = size > 6000
    })

    @Volatile var openChat = 0L
    @Volatile var foreground = false

    // ------------------------------------------------------------ lifecycle

    fun start(ctx: Context, apiId: Int, apiHash: String) {
        if (started) return
        started = true
        app = ctx.applicationContext
        apiIdV = apiId
        apiHashV = apiHash
        applyLogLevel()
        client = Client.create({ o -> onUpdate(o) }, null, null)
        registerNetwork()
    }

    fun applyLogLevel() {
        try {
            val f = TdApi.SetLogVerbosityLevel()
            f.newVerbosityLevel = S.logLevel.v.toIntOrNull() ?: 1
            Client.execute(f)
        } catch (e: Throwable) { }
    }

    private var apiIdV = 0
    private var apiHashV = ""
    fun setCredentials(id: Int, hash: String) { apiIdV = id; apiHashV = hash }

    private fun registerNetwork() {
        try {
            val cm = app.getSystemService(ConnectivityManager::class.java)
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    val t: TdApi.NetworkType = when {
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> TdApi.NetworkTypeWiFi()
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> TdApi.NetworkTypeMobile()
                        else -> TdApi.NetworkTypeOther()
                    }
                    val f = TdApi.SetNetworkType(); f.type = t; fire(f)
                }
                override fun onLost(network: Network) {
                    val f = TdApi.SetNetworkType(); f.type = TdApi.NetworkTypeNone(); fire(f)
                }
            })
        } catch (e: Exception) { }
    }

    fun isMetered(): Boolean = try {
        app.getSystemService(ConnectivityManager::class.java).isActiveNetworkMetered
    } catch (e: Exception) { true }

    fun fire(f: TdApi.Function<*>) { client?.send(f, null) }

    suspend fun call(f: TdApi.Function<*>): TdApi.Object = suspendCoroutine { cont ->
        val c = client
        if (c == null) { cont.resumeWithException(TdError(0, "TDLib not started")); return@suspendCoroutine }
        c.send(f) { r ->
            if (r is TdApi.Error) cont.resumeWithException(TdError(r.code, r.message))
            else cont.resume(r)
        }
    }

    // ------------------------------------------------------------ updates

    private fun mut(chatId: Long, block: (TdApi.Chat) -> Unit) {
        val c = chatCache[chatId] ?: return
        synchronized(c) { block(c) }
        publish()
    }

    private fun onUpdate(o: TdApi.Object) {
        when (o) {
            is TdApi.UpdateAuthorizationState -> handleAuth(o.authorizationState)
            is TdApi.UpdateConnectionState -> conn.value = when (o.state) {
                is TdApi.ConnectionStateReady -> "Online"
                is TdApi.ConnectionStateUpdating -> "Updating…"
                is TdApi.ConnectionStateConnecting -> "Connecting…"
                is TdApi.ConnectionStateConnectingToProxy -> "Connecting to proxy…"
                is TdApi.ConnectionStateWaitingForNetwork -> "Waiting for network…"
                else -> "…"
            }
            is TdApi.UpdateUser -> users[o.user.id] = o.user
            is TdApi.UpdateNewChat -> { chatCache[o.chat.id] = o.chat; publish() }
            is TdApi.UpdateChatLastMessage -> mut(o.chatId) { it.lastMessage = o.lastMessage; it.positions = o.positions }
            is TdApi.UpdateChatReadInbox -> mut(o.chatId) { it.lastReadInboxMessageId = o.lastReadInboxMessageId; it.unreadCount = o.unreadCount }
            is TdApi.UpdateChatReadOutbox -> mut(o.chatId) { it.lastReadOutboxMessageId = o.lastReadOutboxMessageId }
            is TdApi.UpdateChatTitle -> mut(o.chatId) { it.title = o.title }
            is TdApi.UpdateChatPhoto -> mut(o.chatId) { it.photo = o.photo }
            is TdApi.UpdateChatNotificationSettings -> mut(o.chatId) { it.notificationSettings = o.notificationSettings }
            is TdApi.UpdateChatIsMarkedAsUnread -> mut(o.chatId) { it.isMarkedAsUnread = o.isMarkedAsUnread }
            is TdApi.UpdateChatPosition -> mut(o.chatId) { c ->
                val l = c.positions.filter { it.list.javaClass != o.position.list.javaClass }.toMutableList()
                if (o.position.order != 0L) l.add(o.position)
                c.positions = l.toTypedArray()
            }
            is TdApi.UpdateNewMessage -> {
                raw[k(o.message.chatId, o.message.id)] = o.message
                val chat = chatCache[o.message.chatId]
                if (chat != null && !o.message.isOutgoing) Notifier.onMessage(app, o.message, chat)
            }
            is TdApi.UpdateMessageSendSucceeded -> raw[k(o.message.chatId, o.message.id)] = o.message
            is TdApi.UpdateMessageContent -> {
                val m = raw[k(o.chatId, o.messageId)]
                if (m != null) {
                    if (S.saveEdits.v) {
                        val old = describeText(m.content)
                        val neu = describeText(o.newContent)
                        if (old != neu) LocalHistory.addEdit(o.chatId, o.messageId, old)
                    }
                    m.content = o.newContent
                }
            }
            is TdApi.UpdateMessageEdited -> raw[k(o.chatId, o.messageId)]?.editDate = o.editDate
            is TdApi.UpdateMessageInteractionInfo -> raw[k(o.chatId, o.messageId)]?.interactionInfo = o.interactionInfo
            is TdApi.UpdateDeleteMessages -> {
                if (o.isPermanent && !o.fromCache && S.keepDeleted.v) {
                    for (id in o.messageIds) {
                        val key = k(o.chatId, id)
                        if (selfDeleting.remove(key)) continue
                        val m = raw[key] ?: continue
                        val x = toMsg(m)
                        if (x.kind == MKind.TEXT || x.text.isNotBlank()) {
                            LocalHistory.addDeleted(DeletedMsg(x.chatId, x.id, x.out, x.date, x.senderId, x.text.ifBlank { kindLabel(x.kind) }, x.kind.name, System.currentTimeMillis()))
                        }
                    }
                }
            }
            is TdApi.UpdateFile -> onFile(o.file)
            else -> {}
        }
        events.tryEmit(o)
    }

    private fun k(chat: Long, id: Long) = "$chat:$id"

    private val pending = AtomicBoolean(false)
    private fun publish() {
        if (pending.compareAndSet(false, true)) {
            scope.launch {
                delay(120)
                pending.set(false)
                chats.value = chatCache.values.mapNotNull { rowOf(it) }
            }
        }
    }

    private fun rowOf(c: TdApi.Chat): ChatRow? {
        val main = c.positions.firstOrNull { it.list is TdApi.ChatListMain && it.order != 0L }
        val arch = c.positions.firstOrNull { it.list is TdApi.ChatListArchive && it.order != 0L }
        val p = main ?: arch ?: return null
        var uid = 0L
        val kind = when (val t = c.type) {
            is TdApi.ChatTypePrivate -> { uid = t.userId; if (users[t.userId]?.type is TdApi.UserTypeBot) Kind.BOT else Kind.PRIVATE }
            is TdApi.ChatTypeSecret -> { uid = t.userId; Kind.SECRET }
            is TdApi.ChatTypeBasicGroup -> Kind.GROUP
            is TdApi.ChatTypeSupergroup -> if (t.isChannel) Kind.CHANNEL else Kind.GROUP
            else -> Kind.PRIVATE
        }
        val lm = c.lastMessage
        return ChatRow(
            c.id, c.title, kind, if (lm != null) describe(lm.content) else "", lm?.date ?: 0, lm?.isOutgoing ?: false,
            c.unreadCount, p.isPinned, p.order, c.notificationSettings.muteFor > 0, main == null,
            c.photo?.small?.id ?: 0, uid, lm?.id ?: 0, c.isMarkedAsUnread
        )
    }

    // ------------------------------------------------------------ auth

    private fun handleAuth(s: TdApi.AuthorizationState) {
        auth.value = s
        when (s) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> {
                val p = TdApi.SetTdlibParameters()
                p.databaseDirectory = File(app.filesDir, "td").absolutePath
                p.filesDirectory = File(app.filesDir, "td_files").absolutePath
                p.databaseEncryptionKey = SecureKey.databaseKey()
                p.useFileDatabase = true
                p.useChatInfoDatabase = true
                p.useMessageDatabase = true
                p.useSecretChats = false
                p.apiId = apiIdV
                p.apiHash = apiHashV
                p.systemLanguageCode = Locale.getDefault().language.ifBlank { "en" }
                p.deviceModel = Build.MODEL ?: "Android"
                p.systemVersion = Build.VERSION.RELEASE ?: ""
                p.applicationVersion = "1.0"
                fire(p)
            }
            is TdApi.AuthorizationStateReady -> scope.launch {
                try {
                    me.value = call(TdApi.GetMe()) as TdApi.User
                    me.value?.let { users[it.id] = it }
                } catch (e: Exception) { }
                setOnline(foreground)
                loadList(TdApi.ChatListMain())
                loadList(TdApi.ChatListArchive())
            }
            is TdApi.AuthorizationStateClosed -> { started = false; client = null }
            else -> {}
        }
    }

    private suspend fun loadList(list: TdApi.ChatList) {
        try {
            while (true) {
                val f = TdApi.LoadChats(); f.chatList = list; f.limit = 100
                call(f)
            }
        } catch (e: TdError) { /* 404 = everything loaded */ }
        catch (e: Exception) { }
    }

    suspend fun reloadChats() { loadList(TdApi.ChatListMain()); loadList(TdApi.ChatListArchive()) }

    suspend fun sendPhone(n: String) { val f = TdApi.SetAuthenticationPhoneNumber(); f.phoneNumber = n; call(f) }
    suspend fun sendCode(c: String) { val f = TdApi.CheckAuthenticationCode(); f.code = c; call(f) }
    suspend fun sendPassword(p: String) { val f = TdApi.CheckAuthenticationPassword(); f.password = p; call(f) }
    suspend fun logout() { call(TdApi.LogOut()) }

    fun setOnline(on: Boolean) {
        val f = TdApi.SetOption()
        f.name = "online"
        f.value = TdApi.OptionValueBoolean(on && !S.stayOffline.v)
        fire(f)
    }

    // ------------------------------------------------------------ files

    private fun onFile(f: TdApi.File) {
        if (f.local.isDownloadingCompleted && f.local.path.isNotEmpty()) paths[f.id] = f.local.path
        val name = tracked[f.id] ?: return
        files.value = files.value + (f.id to FileInfo(f.id, name, f.size, f.local.downloadedSize, f.local.isDownloadingActive, f.local.isDownloadingCompleted, f.local.path))
    }

    suspend fun localPath(id: Int): String? {
        paths[id]?.let { return it }
        return try {
            val g = TdApi.GetFile(); g.fileId = id
            val f = call(g) as TdApi.File
            if (f.local.isDownloadingCompleted && f.local.path.isNotEmpty()) { paths[id] = f.local.path; f.local.path } else null
        } catch (e: Exception) { null }
    }

    suspend fun download(id: Int, label: String = "", priority: Int = 8): String? {
        localPath(id)?.let { return it }
        if (label.isNotEmpty()) tracked[id] = label
        return try {
            val d = TdApi.DownloadFile()
            d.fileId = id; d.priority = priority; d.offset = 0; d.limit = 0; d.synchronous = true
            val f = call(d) as TdApi.File
            if (f.local.isDownloadingCompleted) { paths[id] = f.local.path; f.local.path } else null
        } catch (e: Exception) { null }
    }

    fun cancelDownload(id: Int) { val c = TdApi.CancelDownloadFile(); c.fileId = id; c.onlyIfPending = false; fire(c) }

    fun canAutoDownload(kind: MKind, size: Long): Boolean {
        if (S.lowData.v) return false
        if (S.autoWifiOnly.v && isMetered()) return false
        if (size > S.autoMaxMb.v * 1024L * 1024L) return false
        return when (kind) {
            MKind.PHOTO, MKind.STICKER -> S.autoPhoto.v
            MKind.VIDEO, MKind.ANIM -> S.autoVideo.v
            else -> false
        }
    }

    // ------------------------------------------------------------ users / chats

    suspend fun user(id: Long): TdApi.User? {
        users[id]?.let { return it }
        return try {
            val g = TdApi.GetUser(); g.userId = id
            (call(g) as TdApi.User).also { users[id] = it }
        } catch (e: Exception) { null }
    }

    fun userName(id: Long): String {
        val u = users[id] ?: chatCache[id]?.let { return it.title } ?: return ""
        return (u.firstName + " " + u.lastName).trim()
    }

    suspend fun chat(id: Long): TdApi.Chat? {
        chatCache[id]?.let { return it }
        return try {
            val g = TdApi.GetChat(); g.chatId = id
            (call(g) as TdApi.Chat).also { chatCache[id] = it }
        } catch (e: Exception) { null }
    }

    suspend fun openPrivate(userId: Long): Long? = try {
        val c = TdApi.CreatePrivateChat(); c.userId = userId; c.force = false
        val chat = call(c) as TdApi.Chat
        chatCache[chat.id] = chat
        chat.id
    } catch (e: Exception) { null }

    suspend fun savedMessagesId(): Long? = me.value?.let { openPrivate(it.id) }

    fun statusText(u: TdApi.User): String = when (val s = u.status) {
        is TdApi.UserStatusOnline -> "online"
        is TdApi.UserStatusOffline -> "last seen " + android.text.format.DateUtils.getRelativeTimeSpanString(s.wasOnline * 1000L, System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS)
        is TdApi.UserStatusRecently -> "last seen recently"
        is TdApi.UserStatusLastWeek -> "last seen within a week"
        is TdApi.UserStatusLastMonth -> "last seen within a month"
        else -> if (u.type is TdApi.UserTypeBot) "bot" else ""
    }

    suspend fun subtitle(c: TdApi.Chat): String = try {
        when (val t = c.type) {
            is TdApi.ChatTypePrivate -> user(t.userId)?.let { statusText(it) } ?: ""
            is TdApi.ChatTypeBasicGroup -> {
                val g = TdApi.GetBasicGroup(); g.basicGroupId = t.basicGroupId
                "${(call(g) as TdApi.BasicGroup).memberCount} members"
            }
            is TdApi.ChatTypeSupergroup -> {
                val g = TdApi.GetSupergroup(); g.supergroupId = t.supergroupId
                val sg = call(g) as TdApi.Supergroup
                if (sg.isChannel) "${sg.memberCount} subscribers" else "${sg.memberCount} members"
            }
            else -> ""
        }
    } catch (e: Exception) { "" }

    // ------------------------------------------------------------ messages

    fun describeText(c: TdApi.MessageContent?): String = when (c) {
        is TdApi.MessageText -> c.text.text
        is TdApi.MessagePhoto -> c.caption.text
        is TdApi.MessageVideo -> c.caption.text
        is TdApi.MessageDocument -> c.caption.text
        is TdApi.MessageAnimation -> c.caption.text
        is TdApi.MessageAudio -> c.caption.text
        is TdApi.MessageVoiceNote -> c.caption.text
        else -> ""
    }

    fun describe(c: TdApi.MessageContent?): String = when (c) {
        null -> ""
        is TdApi.MessageText -> c.text.text
        is TdApi.MessagePhoto -> "🖼 " + c.caption.text.ifEmpty { "Photo" }
        is TdApi.MessageVideo -> "🎬 " + c.caption.text.ifEmpty { "Video" }
        is TdApi.MessageVideoNote -> "🎬 Video message"
        is TdApi.MessageVoiceNote -> "🎤 Voice message"
        is TdApi.MessageDocument -> "📎 " + c.document.fileName
        is TdApi.MessageAudio -> "🎵 " + c.audio.title.ifEmpty { c.audio.fileName }
        is TdApi.MessageSticker -> c.sticker.emoji + " Sticker"
        is TdApi.MessageAnimation -> "GIF"
        is TdApi.MessageContact -> "👤 Contact"
        is TdApi.MessageLocation -> "📍 Location"
        is TdApi.MessagePoll -> "📊 Poll"
        else -> "Message"
    }

    fun kindLabel(k: MKind) = when (k) {
        MKind.PHOTO -> "Photo"; MKind.VIDEO -> "Video"; MKind.VOICE -> "Voice message"
        MKind.FILE -> "File"; MKind.STICKER -> "Sticker"; MKind.ANIM -> "GIF"; else -> "Message"
    }

    private fun ents(t: TdApi.FormattedText): List<Ent> {
        val out = ArrayList<Ent>()
        for (e in t.entities) {
            val ch: Char; var url: String? = null
            when (val ty = e.type) {
                is TdApi.TextEntityTypeBold -> ch = 'b'
                is TdApi.TextEntityTypeItalic -> ch = 'i'
                is TdApi.TextEntityTypeUnderline -> ch = 'u'
                is TdApi.TextEntityTypeStrikethrough -> ch = 's'
                is TdApi.TextEntityTypeSpoiler -> ch = 'p'
                is TdApi.TextEntityTypeCode, is TdApi.TextEntityTypePre, is TdApi.TextEntityTypePreCode -> ch = 'c'
                is TdApi.TextEntityTypeUrl -> {
                    ch = 'l'
                    val raw = t.text.substring(e.offset.coerceIn(0, t.text.length), (e.offset + e.length).coerceIn(0, t.text.length))
                    url = if (raw.contains("://")) raw else "https://$raw"
                }
                is TdApi.TextEntityTypeTextUrl -> { ch = 'l'; url = ty.url }
                else -> continue
            }
            out.add(Ent(e.offset, e.length, ch, url))
        }
        return out
    }

    fun toMsg(m: TdApi.Message): Msg {
        var kind = MKind.OTHER; var text = ""; var file = 0; var w = 0; var h = 0; var size = 0L
        var name = ""; var dur = 0; var en: List<Ent> = emptyList()
        when (val c = m.content) {
            is TdApi.MessageText -> { kind = MKind.TEXT; text = c.text.text; en = ents(c.text) }
            is TdApi.MessagePhoto -> {
                kind = MKind.PHOTO; text = c.caption.text; en = ents(c.caption)
                val s = c.photo.sizes.lastOrNull()
                if (s != null) { file = s.photo.id; w = s.width; h = s.height; size = s.photo.size }
            }
            is TdApi.MessageVideo -> {
                kind = MKind.VIDEO; text = c.caption.text; en = ents(c.caption)
                file = c.video.video.id; w = c.video.width; h = c.video.height; dur = c.video.duration; size = c.video.video.size; name = c.video.fileName
            }
            is TdApi.MessageVideoNote -> { kind = MKind.VIDEO; file = c.videoNote.video.id; dur = c.videoNote.duration; size = c.videoNote.video.size; w = 240; h = 240 }
            is TdApi.MessageVoiceNote -> { kind = MKind.VOICE; text = c.caption.text; file = c.voiceNote.voice.id; dur = c.voiceNote.duration; size = c.voiceNote.voice.size }
            is TdApi.MessageDocument -> {
                kind = MKind.FILE; text = c.caption.text; en = ents(c.caption)
                file = c.document.document.id; name = c.document.fileName; size = c.document.document.size
            }
            is TdApi.MessageAudio -> {
                kind = MKind.FILE; text = c.caption.text; file = c.audio.audio.id
                name = c.audio.fileName.ifEmpty { c.audio.title }; size = c.audio.audio.size
            }
            is TdApi.MessageSticker -> {
                kind = MKind.STICKER; text = c.sticker.emoji
                if (c.sticker.format is TdApi.StickerFormatWebp) { file = c.sticker.sticker.id; size = c.sticker.sticker.size }
                w = c.sticker.width; h = c.sticker.height
            }
            is TdApi.MessageAnimation -> {
                kind = MKind.ANIM; text = c.caption.text; file = c.animation.animation.id
                w = c.animation.width; h = c.animation.height; size = c.animation.animation.size
            }
            else -> { kind = MKind.OTHER; text = describe(c) }
        }
        val sender = when (val s = m.senderId) {
            is TdApi.MessageSenderUser -> s.userId
            is TdApi.MessageSenderChat -> s.chatId
            else -> 0L
        }
        val reply = (m.replyTo as? TdApi.MessageReplyToMessage)?.messageId ?: 0L
        val rs = ArrayList<Pair<String, Int>>()
        val mine = ArrayList<String>()
        m.interactionInfo?.reactions?.reactions?.forEach { r ->
            val e = (r.type as? TdApi.ReactionTypeEmoji)?.emoji
            if (e != null) { rs.add(e to r.totalCount); if (r.isChosen) mine.add(e) }
        }
        return Msg(
            m.id, m.chatId, m.isOutgoing, m.date, sender, text, en, kind, file, size, name, w, h, dur, reply,
            m.editDate > 0, m.forwardInfo != null, rs, mine, false, m.sendingState != null
        )
    }

    fun rawMsg(chat: Long, id: Long): TdApi.Message? = raw[k(chat, id)]

    fun cacheMessages(list: Collection<TdApi.Message>) { list.forEach { raw[k(it.chatId, it.id)] = it } }

    fun cachedMediaFor(chat: Long): List<Msg> =
        synchronized(raw) { raw.values.filter { it.chatId == chat } }
            .map { toMsg(it) }
            .filter { it.kind == MKind.PHOTO || it.kind == MKind.VIDEO || it.kind == MKind.ANIM }
            .sortedBy { it.id }

    suspend fun history(chatId: Long, from: Long, offset: Int, limit: Int): List<Msg> {
        val f = TdApi.GetChatHistory()
        f.chatId = chatId; f.fromMessageId = from; f.offset = offset; f.limit = limit; f.onlyLocal = false
        val r = call(f) as TdApi.Messages
        val list = r.messages.filterNotNull()
        cacheMessages(list)
        return list.map { toMsg(it) }
    }

    suspend fun getMessage(chatId: Long, id: Long): Msg? {
        raw[k(chatId, id)]?.let { return toMsg(it) }
        return try {
            val g = TdApi.GetMessage(); g.chatId = chatId; g.messageId = id
            val m = call(g) as TdApi.Message
            raw[k(chatId, id)] = m
            toMsg(m)
        } catch (e: Exception) { null }
    }

    private fun fmt(text: String, entities: List<TdApi.TextEntity>): TdApi.FormattedText {
        val ft = TdApi.FormattedText()
        ft.text = text
        ft.entities = entities.toTypedArray()
        return ft
    }

    /** Minimal markdown: **bold** __italic__ `code` ~~strike~~ ||spoiler|| */
    fun parseMarkdown(src: String): TdApi.FormattedText {
        if (!S.mdFormat.v) return fmt(src, emptyList())
        val marks = listOf("**" to 'b', "__" to 'i', "~~" to 's', "||" to 'p', "`" to 'c')
        val sb = StringBuilder()
        val ents = ArrayList<TdApi.TextEntity>()
        var i = 0
        while (i < src.length) {
            var matched = false
            for ((m, t) in marks) {
                if (src.startsWith(m, i)) {
                    val end = src.indexOf(m, i + m.length)
                    if (end > i + m.length) {
                        val inner = src.substring(i + m.length, end)
                        val e = TdApi.TextEntity()
                        e.offset = sb.length; e.length = inner.length
                        e.type = when (t) {
                            'b' -> TdApi.TextEntityTypeBold()
                            'i' -> TdApi.TextEntityTypeItalic()
                            's' -> TdApi.TextEntityTypeStrikethrough()
                            'p' -> TdApi.TextEntityTypeSpoiler()
                            else -> TdApi.TextEntityTypeCode()
                        }
                        ents.add(e)
                        sb.append(inner)
                        i = end + m.length
                        matched = true
                        break
                    }
                }
            }
            if (!matched) { sb.append(src[i]); i++ }
        }
        return fmt(sb.toString(), ents)
    }

    private fun textContent(text: String): TdApi.InputMessageText {
        val c = TdApi.InputMessageText()
        c.text = parseMarkdown(text)
        return c
    }

    suspend fun sendText(chatId: Long, text: String, replyTo: Long = 0) {
        val f = TdApi.SendMessage()
        f.chatId = chatId
        f.inputMessageContent = textContent(text)
        if (replyTo != 0L) { val r = TdApi.InputMessageReplyToMessage(); r.messageId = replyTo; f.replyTo = r }
        call(f)
    }

    suspend fun sendPhoto(chatId: Long, path: String, caption: String, replyTo: Long = 0) {
        val c = TdApi.InputMessagePhoto()
        c.photo = TdApi.InputFileLocal(path)
        c.addedStickerFileIds = IntArray(0)
        c.caption = parseMarkdown(caption)
        val f = TdApi.SendMessage()
        f.chatId = chatId; f.inputMessageContent = c
        if (replyTo != 0L) { val r = TdApi.InputMessageReplyToMessage(); r.messageId = replyTo; f.replyTo = r }
        call(f)
    }

    suspend fun sendFile(chatId: Long, path: String, caption: String, replyTo: Long = 0) {
        val c = TdApi.InputMessageDocument()
        c.document = TdApi.InputFileLocal(path)
        c.caption = parseMarkdown(caption)
        val f = TdApi.SendMessage()
        f.chatId = chatId; f.inputMessageContent = c
        if (replyTo != 0L) { val r = TdApi.InputMessageReplyToMessage(); r.messageId = replyTo; f.replyTo = r }
        call(f)
    }

    suspend fun editText(chatId: Long, id: Long, text: String) {
        val f = TdApi.EditMessageText()
        f.chatId = chatId; f.messageId = id; f.inputMessageContent = textContent(text)
        call(f)
    }

    suspend fun deleteMessages(chatId: Long, ids: List<Long>, forAll: Boolean) {
        ids.forEach { selfDeleting.add(k(chatId, it)) }
        val f = TdApi.DeleteMessages()
        f.chatId = chatId; f.messageIds = ids.toLongArray(); f.revoke = forAll
        call(f)
    }

    suspend fun forward(toChat: Long, fromChat: Long, ids: List<Long>, copy: Boolean = false) {
        val f = TdApi.ForwardMessages()
        f.chatId = toChat; f.fromChatId = fromChat; f.messageIds = ids.toLongArray(); f.sendCopy = copy
        call(f)
    }

    suspend fun pin(chatId: Long, id: Long, unpin: Boolean = false) {
        if (unpin) { val f = TdApi.UnpinChatMessage(); f.chatId = chatId; f.messageId = id; call(f) }
        else { val f = TdApi.PinChatMessage(); f.chatId = chatId; f.messageId = id; f.disableNotification = true; call(f) }
    }

    suspend fun react(chatId: Long, id: Long, emoji: String, remove: Boolean) {
        val t = TdApi.ReactionTypeEmoji(); t.emoji = emoji
        if (remove) { val f = TdApi.RemoveMessageReaction(); f.chatId = chatId; f.messageId = id; f.reactionType = t; call(f) }
        else { val f = TdApi.AddMessageReaction(); f.chatId = chatId; f.messageId = id; f.reactionType = t; f.isBig = false; f.updateRecentReactions = true; call(f) }
    }

    suspend fun translate(text: String, lang: String): String {
        val f = TdApi.TranslateText()
        f.text = fmt(text, emptyList()); f.toLanguageCode = lang
        return (call(f) as TdApi.FormattedText).text
    }

    fun markRead(chatId: Long, ids: List<Long>) {
        val f = TdApi.ViewMessages()
        f.chatId = chatId; f.messageIds = ids.toLongArray(); f.forceRead = true
        fire(f)
    }

    fun sendTyping(chatId: Long) {
        if (!S.sendTyping.v) return
        val f = TdApi.SendChatAction()
        f.chatId = chatId; f.action = TdApi.ChatActionTyping()
        fire(f)
    }

    fun setUnreadMark(chatId: Long, v: Boolean) {
        val f = TdApi.ToggleChatIsMarkedAsUnread(); f.chatId = chatId; f.isMarkedAsUnread = v; fire(f)
    }

    fun archive(chatId: Long, toArchive: Boolean) {
        val f = TdApi.AddChatToList()
        f.chatId = chatId; f.chatList = if (toArchive) TdApi.ChatListArchive() else TdApi.ChatListMain()
        fire(f)
    }

    fun pinChat(chatId: Long, pinned: Boolean, archived: Boolean) {
        val f = TdApi.ToggleChatIsPinned()
        f.chatList = if (archived) TdApi.ChatListArchive() else TdApi.ChatListMain()
        f.chatId = chatId; f.isPinned = pinned
        fire(f)
    }

    fun mute(chatId: Long, muted: Boolean) {
        val c = chatCache[chatId] ?: return
        val ns = c.notificationSettings
        ns.useDefaultMuteFor = false
        ns.muteFor = if (muted) 366 * 24 * 3600 else 0
        val f = TdApi.SetChatNotificationSettings(); f.chatId = chatId; f.notificationSettings = ns
        fire(f)
    }

    fun readChat(row: ChatRow) {
        if (row.unread > 0 && row.lastMsgId != 0L) markRead(row.id, listOf(row.lastMsgId))
        if (row.markedUnread) setUnreadMark(row.id, false)
    }

    // ------------------------------------------------------------ search

    private fun filterOf(name: String): TdApi.SearchMessagesFilter? = when (name) {
        "Photos" -> TdApi.SearchMessagesFilterPhoto()
        "Videos" -> TdApi.SearchMessagesFilterVideo()
        "Documents" -> TdApi.SearchMessagesFilterDocument()
        "GIFs" -> TdApi.SearchMessagesFilterAnimation()
        "Voice" -> TdApi.SearchMessagesFilterVoiceNote()
        "Links" -> TdApi.SearchMessagesFilterUrl()
        else -> null
    }

    suspend fun searchGlobal(query: String, type: String, minDate: Int, maxDate: Int): List<Hit> {
        val f = TdApi.SearchMessages()
        f.chatList = null
        f.query = query; f.offset = ""; f.limit = 50
        f.filter = filterOf(type)
        f.minDate = minDate; f.maxDate = maxDate
        val r = call(f) as TdApi.FoundMessages
        val list = r.messages.filterNotNull()
        cacheMessages(list)
        return list.map { Hit(toMsg(it), chatCache[it.chatId]?.title ?: chat(it.chatId)?.title ?: "") }
    }

    /** sender: 0 = anyone, otherwise user id */
    suspend fun searchInChat(chatId: Long, query: String, type: String, sender: Long): List<Hit> {
        val f = TdApi.SearchChatMessages()
        f.chatId = chatId; f.query = query; f.fromMessageId = 0; f.offset = 0; f.limit = 50
        f.filter = filterOf(type)
        if (sender != 0L) { val s = TdApi.MessageSenderUser(); s.userId = sender; f.senderId = s }
        val r = call(f) as TdApi.FoundChatMessages
        val list = r.messages.filterNotNull()
        cacheMessages(list)
        val title = chatCache[chatId]?.title ?: ""
        return list.map { Hit(toMsg(it), title) }
    }

    suspend fun searchPublic(query: String): List<Long> = try {
        val f = TdApi.SearchPublicChats(); f.query = query.removePrefix("@")
        val r = call(f) as TdApi.Chats
        r.chatIds.toList().also { ids -> ids.forEach { chat(it) } }
    } catch (e: Exception) { emptyList() }

    suspend fun mediaOf(chatId: Long, type: String, from: Long = 0): List<Msg> = try {
        val f = TdApi.SearchChatMessages()
        f.chatId = chatId; f.query = ""; f.fromMessageId = from; f.offset = 0; f.limit = 60
        f.filter = filterOf(type)
        val r = call(f) as TdApi.FoundChatMessages
        val list = r.messages.filterNotNull()
        cacheMessages(list)
        list.map { toMsg(it) }
    } catch (e: Exception) { emptyList() }

    suspend fun pinnedMessage(chatId: Long): Msg? = try {
        val f = TdApi.GetChatPinnedMessage(); f.chatId = chatId
        val m = call(f) as TdApi.Message
        raw[k(chatId, m.id)] = m
        toMsg(m)
    } catch (e: Exception) { null }

    suspend fun contacts(): List<TdApi.User> = try {
        val r = call(TdApi.GetContacts()) as TdApi.Users
        r.userIds.mapNotNull { user(it) }
    } catch (e: Exception) { emptyList() }

    // ------------------------------------------------------------ account

    suspend fun setName(first: String, last: String) { val f = TdApi.SetName(); f.firstName = first; f.lastName = last; call(f) }
    suspend fun setBio(bio: String) { val f = TdApi.SetBio(); f.bio = bio; call(f) }
    suspend fun setUsername(u: String) { val f = TdApi.SetUsername(); f.username = u; call(f) }
    suspend fun setProfilePhoto(path: String) {
        val p = TdApi.InputChatPhotoStatic(); p.photo = TdApi.InputFileLocal(path)
        val f = TdApi.SetProfilePhoto(); f.photo = p
        call(f)
    }

    suspend fun sessions(): List<TdApi.Session> =
        (call(TdApi.GetActiveSessions()) as TdApi.Sessions).sessions.filterNotNull()

    suspend fun terminate(id: Long) { val f = TdApi.TerminateSession(); f.sessionId = id; call(f) }

    private fun privacySetting(which: String): TdApi.UserPrivacySetting = when (which) {
        "status" -> TdApi.UserPrivacySettingShowStatus()
        "photo" -> TdApi.UserPrivacySettingShowProfilePhoto()
        else -> TdApi.UserPrivacySettingShowPhoneNumber()
    }

    suspend fun getPrivacy(which: String): String = try {
        val f = TdApi.GetUserPrivacySettingRules(); f.setting = privacySetting(which)
        val r = call(f) as TdApi.UserPrivacySettingRules
        when (r.rules.firstOrNull()) {
            is TdApi.UserPrivacySettingRuleAllowAll -> "Everybody"
            is TdApi.UserPrivacySettingRuleAllowContacts -> "My contacts"
            is TdApi.UserPrivacySettingRuleRestrictAll -> "Nobody"
            null -> "Nobody"
            else -> "Custom"
        }
    } catch (e: Exception) { "?" }

    /** Replaces the rule list with a simple one. Custom per-user exceptions are overwritten. */
    suspend fun setPrivacy(which: String, value: String) {
        val rules: Array<TdApi.UserPrivacySettingRule> = when (value) {
            "Everybody" -> arrayOf(TdApi.UserPrivacySettingRuleAllowAll())
            "My contacts" -> arrayOf(TdApi.UserPrivacySettingRuleAllowContacts(), TdApi.UserPrivacySettingRuleRestrictAll())
            else -> arrayOf(TdApi.UserPrivacySettingRuleRestrictAll())
        }
        val f = TdApi.SetUserPrivacySettingRules()
        f.setting = privacySetting(which)
        f.rules = TdApi.UserPrivacySettingRules(rules)
        call(f)
    }

    suspend fun tdVersion(): String = try {
        val g = TdApi.GetOption(); g.name = "version"
        (call(g) as TdApi.OptionValueString).value
    } catch (e: Exception) { "?" }

    suspend fun storageBytes(): Long = try {
        (call(TdApi.GetStorageStatisticsFast()) as TdApi.StorageStatisticsFast).filesSize
    } catch (e: Exception) { -1 }

    /** ttlSeconds = 0 and size = 0 clear everything; use chatIds to limit to certain chats. */
    suspend fun optimize(maxAgeDays: Int, chatIds: List<Long> = emptyList(), all: Boolean = false) {
        val f = TdApi.OptimizeStorage()
        f.size = if (all) 0 else -1
        f.ttl = if (all) 0 else maxAgeDays * 86400
        f.count = -1
        f.immunityDelay = if (all) 0 else -1
        f.fileTypes = emptyArray()
        f.chatIds = chatIds.toLongArray()
        f.excludeChatIds = LongArray(0)
        f.returnDeletedFileStatistics = false
        f.chatLimit = 0
        call(f)
    }
}
