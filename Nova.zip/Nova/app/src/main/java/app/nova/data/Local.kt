package app.nova.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

// ---------------------------------------------------------------- banner

data class BannerCfg(
    val kind: String = "none",          // none | image | gif | video | gradient
    val path: String = "",
    val g1: Long = 0xFF2C5CB8L,
    val g2: Long = 0xFF7A3FD1L,
    val posY: Int = 50,                 // 0..100 vertical focus
    val scale: Int = 100,               // 100..250 %
    val blur: Int = 0,                  // 0..25 dp
    val brightness: Int = 100,          // 20..150 %
    val overlay: Int = 25,              // 0..90 % black overlay
    val parallax: Boolean = true,
    val animate: Boolean = true
) {
    fun toJson(): String = JSONObject().apply {
        put("kind", kind); put("path", path); put("g1", g1); put("g2", g2); put("posY", posY)
        put("scale", scale); put("blur", blur); put("brightness", brightness); put("overlay", overlay)
        put("parallax", parallax); put("animate", animate)
    }.toString()

    companion object {
        fun parse(s: String): BannerCfg = try {
            val o = JSONObject(s)
            BannerCfg(
                o.optString("kind", "none"), o.optString("path", ""), o.optLong("g1", 0xFF2C5CB8L), o.optLong("g2", 0xFF7A3FD1L),
                o.optInt("posY", 50), o.optInt("scale", 100), o.optInt("blur", 0), o.optInt("brightness", 100),
                o.optInt("overlay", 25), o.optBoolean("parallax", true), o.optBoolean("animate", true)
            )
        } catch (e: Exception) { BannerCfg() }
    }
}

object Banners {
    private val cache = HashMap<Long, androidx.compose.runtime.MutableState<BannerCfg>>()

    fun state(userId: Long): androidx.compose.runtime.MutableState<BannerCfg> =
        cache.getOrPut(userId) { mutableStateOf(BannerCfg.parse(S.str("banner_$userId"))) }

    fun save(userId: Long, cfg: BannerCfg) {
        state(userId).value = cfg
        S.setStr("banner_$userId", cfg.toJson())
    }

    /** Copies a picked media file into app storage and returns its path. */
    fun importMedia(ctx: Context, uri: android.net.Uri, userId: Long): Pair<String, String>? {
        return try {
            val mime = ctx.contentResolver.getType(uri) ?: ""
            val kind = when {
                mime == "image/gif" -> "gif"
                mime.startsWith("video") -> "video"
                else -> "image"
            }
            val dir = File(ctx.filesDir, "banners").apply { mkdirs() }
            val ext = when (kind) { "gif" -> "gif"; "video" -> "mp4"; else -> "img" }
            val out = File(dir, "${userId}_${System.currentTimeMillis()}.$ext")
            ctx.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            out.absolutePath to kind
        } catch (e: Exception) { null }
    }
}

// ---------------------------------------------------------------- local folders

data class LocalFolder(val id: String, val name: String, val icon: String, val chatIds: List<Long>)

object LocalFolders {
    val list = mutableStateListOf<LocalFolder>()

    fun load() {
        list.clear()
        try {
            val a = JSONArray(S.str("local_folders", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val ids = o.getJSONArray("chats")
                list.add(LocalFolder(o.getString("id"), o.getString("name"), o.optString("icon", "📁"), (0 until ids.length()).map { ids.getLong(it) }))
            }
        } catch (e: Exception) { }
    }

    private fun persist() {
        val a = JSONArray()
        list.forEach { f ->
            a.put(JSONObject().put("id", f.id).put("name", f.name).put("icon", f.icon).put("chats", JSONArray(f.chatIds)))
        }
        S.setStr("local_folders", a.toString())
    }

    fun upsert(f: LocalFolder) {
        val i = list.indexOfFirst { it.id == f.id }
        if (i >= 0) list[i] = f else list.add(f)
        persist()
    }

    fun remove(id: String) { list.removeAll { it.id == id }; persist() }

    fun move(id: String, delta: Int) {
        val i = list.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) return
        val x = list.removeAt(i); list.add(j, x); persist()
    }
}

// ---------------------------------------------------------------- local profile extras

object LocalProfile {
    val status = mutableStateOf("")
    val music = mutableStateOf("")
    val links = mutableStateOf("")
    val badges = mutableStateOf("")

    fun load() {
        status.value = S.str("lp_status"); music.value = S.str("lp_music")
        links.value = S.str("lp_links"); badges.value = S.str("lp_badges")
    }

    fun save(status: String, music: String, links: String, badges: String) {
        this.status.value = status; this.music.value = music; this.links.value = links; this.badges.value = badges
        S.setStr("lp_status", status); S.setStr("lp_music", music); S.setStr("lp_links", links); S.setStr("lp_badges", badges)
    }
}

// ---------------------------------------------------------------- local history (edits + deleted)

data class DeletedMsg(
    val chatId: Long, val id: Long, val out: Boolean, val date: Int,
    val senderId: Long, val text: String, val kind: String, val savedAt: Long
)

object LocalHistory {
    private lateinit var file: File
    val edits = HashMap<String, MutableList<String>>()
    val deleted = ArrayList<DeletedMsg>()

    fun key(chatId: Long, id: Long) = "$chatId:$id"

    @Synchronized
    fun load(ctx: Context) {
        file = File(ctx.filesDir, "local_history.json")
        edits.clear(); deleted.clear()
        try {
            if (!file.exists()) return
            val o = JSONObject(file.readText())
            val ttlMs = S.localTtl.v * 86_400_000L
            val now = System.currentTimeMillis()
            val e = o.optJSONObject("edits")
            e?.keys()?.forEach { k ->
                val arr = e.getJSONArray(k)
                edits[k] = (0 until arr.length()).map { arr.getString(it) }.toMutableList()
            }
            val d = o.optJSONArray("deleted")
            if (d != null) for (i in 0 until d.length()) {
                val x = d.getJSONObject(i)
                val m = DeletedMsg(x.getLong("chat"), x.getLong("id"), x.getBoolean("out"), x.getInt("date"), x.getLong("sender"), x.getString("text"), x.getString("kind"), x.optLong("saved", now))
                if (ttlMs == 0L || now - m.savedAt < ttlMs) deleted.add(m)
            }
        } catch (e: Exception) { }
    }

    @Synchronized
    fun save() {
        try {
            val e = JSONObject()
            edits.forEach { (k, v) -> e.put(k, JSONArray(v)) }
            val d = JSONArray()
            deleted.forEach { m ->
                d.put(JSONObject().put("chat", m.chatId).put("id", m.id).put("out", m.out).put("date", m.date)
                    .put("sender", m.senderId).put("text", m.text).put("kind", m.kind).put("saved", m.savedAt))
            }
            file.writeText(JSONObject().put("edits", e).put("deleted", d).toString())
        } catch (ex: Exception) { }
    }

    @Synchronized
    fun addEdit(chatId: Long, id: Long, oldText: String) {
        if (oldText.isBlank()) return
        val l = edits.getOrPut(key(chatId, id)) { mutableListOf() }
        if (l.lastOrNull() != oldText) l.add(oldText)
        save()
    }

    @Synchronized
    fun addDeleted(m: DeletedMsg) {
        if (deleted.none { it.chatId == m.chatId && it.id == m.id }) { deleted.add(m); save() }
    }

    @Synchronized
    fun deletedFor(chatId: Long): List<DeletedMsg> = deleted.filter { it.chatId == chatId }

    @Synchronized
    fun editsFor(chatId: Long, id: Long): List<String> = edits[key(chatId, id)]?.toList() ?: emptyList()

    @Synchronized
    fun clearAll() { edits.clear(); deleted.clear(); save() }
}

// ---------------------------------------------------------------- secure storage

object SecureKey {
    private const val ALIAS = "nova_db_key"
    private fun ks(): KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun wrapKey(): SecretKey {
        val store = ks()
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return g.generateKey()
    }

    /** Random 32-byte key for the TDLib database, wrapped by an Android Keystore key. */
    fun databaseKey(): ByteArray {
        val stored = S.str("db_key_blob")
        val wk = wrapKey()
        if (stored.isNotEmpty()) {
            try {
                val raw = Base64.decode(stored, Base64.NO_WRAP)
                val iv = raw.copyOfRange(0, 12)
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, wk, GCMParameterSpec(128, iv))
                return c.doFinal(raw, 12, raw.size - 12)
            } catch (e: Exception) { /* fall through, regenerate */ }
        }
        val key = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, wk)
        val enc = c.doFinal(key)
        S.setStr("db_key_blob", Base64.encodeToString(c.iv + enc, Base64.NO_WRAP))
        return key
    }
}

object Pin {
    private fun hash(pin: String, salt: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
        return Base64.encodeToString(d, Base64.NO_WRAP)
    }

    fun isSet() = S.str("pin_hash").isNotEmpty()

    fun set(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.let { Base64.encodeToString(it, Base64.NO_WRAP) }
        S.setStr("pin_salt", salt); S.setStr("pin_hash", hash(pin, salt))
    }

    fun clear() { S.setStr("pin_salt", ""); S.setStr("pin_hash", "") }

    fun verify(pin: String): Boolean = isSet() && hash(pin, S.str("pin_salt")) == S.str("pin_hash")
}
