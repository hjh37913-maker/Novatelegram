@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package app.nova.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nova.data.LocalFolders
import app.nova.data.S
import app.nova.tg.ChatRow
import app.nova.tg.Kind
import app.nova.tg.Tg
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object MainState {
    val listState = LazyListState()
    var tab by mutableIntStateOf(0)
    var folder by mutableStateOf("all")
    val sel = mutableStateListOf<Long>()
    var revealed by mutableStateOf(false)
}

enum class Tab(val label: String, val icon: ImageVector) {
    CHATS("Chats", Icons.Filled.Chat),
    CONTACTS("Contacts", Icons.Filled.Contacts),
    SEARCH("Search", Icons.Filled.Search),
    PROFILE("Profile", Icons.Filled.Person),
    SETTINGS("Settings", Icons.Filled.Settings)
}

fun currentTabs(): List<Tab> = S.navPreset.v.split(" · ").mapNotNull { n -> Tab.values().firstOrNull { it.label == n.trim() } }
    .ifEmpty { listOf(Tab.CHATS, Tab.SETTINGS) }

@Composable
fun MainScreen() {
    val c = Nova.c
    val tabs = currentTabs()
    val idx = MainState.tab.coerceIn(0, tabs.size - 1)
    val chats by Tg.chats.collectAsState()
    val smartUnread = chats.filter { !it.muted && !it.archived }.sumOf { it.unread }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tabs[idx]) {
                Tab.CHATS -> ChatsTab(tabs)
                Tab.CONTACTS -> ContactsTab()
                Tab.SEARCH -> SearchScreen(0L, embedded = true)
                Tab.PROFILE -> Tg.me.collectAsState().value?.let { ProfileScreen(Route.Profile(it.id), embedded = true) }
                Tab.SETTINGS -> SettingsScreen(null, embedded = true)
            }
        }
        Row(Modifier.fillMaxWidth().background(c.nav).border(0.5.dp, c.border).height(if (S.navLabels.v) 64.dp else 52.dp)) {
            tabs.forEachIndexed { i, t ->
                val sel = i == idx
                Column(
                    Modifier.weight(1f).fillMaxSize().springClick { MainState.tab = i }, horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box {
                        Icon(t.icon, null, tint = if (sel) c.accent else c.icon)
                        if (t == Tab.CHATS && smartUnread > 0) {
                            Box(
                                Modifier.align(Alignment.TopEnd).padding(start = 18.dp).clip(CircleShape).background(c.accent).padding(horizontal = 5.dp)
                            ) { Text(if (smartUnread > 99) "99+" else "$smartUnread", color = Color.White, fontSize = 10.sp) }
                        }
                    }
                    if (S.navLabels.v) Text(t.label, color = if (sel) c.accent else c.sec, fontSize = 11.sp)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ chats tab

private fun filterAndSort(all: List<ChatRow>, folder: String): List<ChatRow> {
    var l = all.filter { r ->
        if (folder == "archive") r.archived
        else !r.archived && when (folder) {
            "all" -> true
            "unread" -> r.unread > 0 || r.markedUnread
            "personal" -> r.kind == Kind.PRIVATE || r.kind == Kind.SECRET
            "groups" -> r.kind == Kind.GROUP
            "channels" -> r.kind == Kind.CHANNEL
            "bots" -> r.kind == Kind.BOT
            else -> if (folder.startsWith("f:")) LocalFolders.list.firstOrNull { it.id == folder.drop(2) }?.chatIds?.contains(r.id) == true else true
        }
    }
    if (S.unreadOnly.v && folder != "archive") l = l.filter { it.unread > 0 || it.markedUnread }
    if (S.importantOnly.v) l = l.filter { !it.muted }
    val base = when (S.sortMode.v) {
        "Last activity" -> l.sortedByDescending { it.lastDate }
        "Unread first" -> l.sortedWith(compareByDescending<ChatRow> { it.unread > 0 }.thenByDescending { it.order })
        "By type" -> l.sortedWith(compareBy<ChatRow> { it.kind.ordinal }.thenByDescending { it.order })
        else -> l.sortedByDescending { it.order }
    }
    return if (S.pinnedFirst.v) base.sortedByDescending { it.pinned } else base
}

private fun actionLabel(a: String, r: ChatRow): String = when (a) {
    "Read / Unread" -> if (r.unread > 0 || r.markedUnread) "Mark read" else "Mark unread"
    "Pin / Unpin" -> if (r.pinned) "Unpin" else "Pin"
    "Archive" -> if (r.archived) "Unarchive" else "Archive"
    else -> if (r.muted) "Unmute" else "Mute"
}

private fun doAction(a: String, r: ChatRow) {
    when (a) {
        "Read / Unread" -> if (r.unread > 0 || r.markedUnread) Tg.readChat(r) else Tg.setUnreadMark(r.id, true)
        "Pin / Unpin" -> Tg.pinChat(r.id, !r.pinned, r.archived)
        "Archive" -> Tg.archive(r.id, !r.archived)
        else -> Tg.mute(r.id, !r.muted)
    }
}

@Composable
fun ChatsTab(tabs: List<Tab>) {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    val all by Tg.chats.collectAsState()
    val me by Tg.me.collectAsState()
    val conn by Tg.conn.collectAsState()
    val rows = filterAndSort(all, MainState.folder)
    val selecting = MainState.sel.isNotEmpty()
    var menu by remember { mutableStateOf(false) }
    var createMenu by remember { mutableStateOf(false) }
    var pickContact by remember { mutableStateOf(false) }
    var refreshing by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        // ---- top bar
        Row(Modifier.fillMaxWidth().background(c.surface).padding(horizontal = 8.dp).height(60.dp), verticalAlignment = Alignment.CenterVertically) {
            if (selecting) {
                IconButton({ MainState.sel.clear() }) { Icon(Icons.Filled.Close, null, tint = c.text) }
                Text("${MainState.sel.size} selected", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                val selRows = rows.filter { it.id in MainState.sel }
                IconButton({ selRows.forEach { Tg.readChat(it) }; MainState.sel.clear() }) { Icon(Icons.Filled.DoneAll, null, tint = c.icon) }
                IconButton({ val pin = selRows.any { !it.pinned }; selRows.forEach { Tg.pinChat(it.id, pin, it.archived) }; MainState.sel.clear() }) { Icon(Icons.Filled.PushPin, null, tint = c.icon) }
                IconButton({ val ar = selRows.any { !it.archived }; selRows.forEach { Tg.archive(it.id, ar) }; MainState.sel.clear() }) { Icon(Icons.Filled.Archive, null, tint = c.icon) }
                IconButton({ val m = selRows.any { !it.muted }; selRows.forEach { Tg.mute(it.id, m) }; MainState.sel.clear() }) { Icon(Icons.Filled.VolumeOff, null, tint = c.icon) }
                IconButton({ val ids = selRows.map { it.id }; MainState.sel.clear(); scope.launch { try { Tg.optimize(0, ids, all = true) } catch (e: Exception) { } } }) {
                    Icon(Icons.Filled.CleaningServices, null, tint = c.icon)
                }
            } else {
                Box(Modifier.springClick { me?.let { Nav.push(Route.Profile(it.id)) } }.padding(4.dp)) {
                    Avatar(me?.profilePhoto?.small?.id ?: 0, me?.firstName ?: "N", 38.dp)
                }
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text("Nova", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).clip(CircleShape).background(if (conn == "Online") Color(0xFF3DDC97) else Color(0xFFFFB84D)))
                        Text(conn, color = c.sec, fontSize = 12.sp, modifier = Modifier.padding(start = 5.dp))
                    }
                }
                IconButton({
                    val si = tabs.indexOf(Tab.SEARCH)
                    if (si >= 0) MainState.tab = si else Nav.push(Route.Search())
                }) { Icon(Icons.Filled.Search, null, tint = c.icon) }
                Box {
                    IconButton({ createMenu = true }) { Icon(Icons.Filled.Edit, null, tint = c.icon) }
                    DropdownMenu(createMenu, { createMenu = false }, containerColor = c.surface2) {
                        DropdownMenuItem({ Text("Saved Messages", color = c.text) }, { createMenu = false; scope.launch { Tg.savedMessagesId()?.let { Nav.openChat(it) } } })
                        DropdownMenuItem({ Text("New message", color = c.text) }, { createMenu = false; pickContact = true })
                    }
                }
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, null, tint = c.icon) }
                    DropdownMenu(menu, { menu = false }, containerColor = c.surface2) {
                        DropdownMenuItem({ Text("Mark all as read", color = c.text) }, { menu = false; all.filter { !it.archived && (it.unread > 0 || it.markedUnread) }.forEach { Tg.readChat(it) } })
                        DropdownMenuItem({ Text(if (S.unreadOnly.v) "Show all chats" else "Unread only", color = c.text) }, { menu = false; S.unreadOnly.set(!S.unreadOnly.v) })
                        DropdownMenuItem({ Text(if (S.importantOnly.v) "Show muted chats" else "Important only", color = c.text) }, { menu = false; S.importantOnly.set(!S.importantOnly.v) })
                        if (S.privacyMode.v) DropdownMenuItem(
                            { Text(if (MainState.revealed) "Hide previews" else "Reveal previews", color = c.text) },
                            { menu = false; MainState.revealed = !MainState.revealed }
                        )
                        if (S.appLock.v) DropdownMenuItem({ Text("Lock now", color = c.text) }, { menu = false; Lock.lockNow() })
                        DropdownMenuItem({ Text("Settings", color = c.text) }, { menu = false; val si = tabs.indexOf(Tab.SETTINGS); if (si >= 0) MainState.tab = si else Nav.push(Route.Settings(null)) })
                    }
                }
            }
        }

        // ---- folder chips
        if (S.folderChips.v && !selecting) {
            LazyRow(Modifier.fillMaxWidth().background(c.surface).padding(bottom = 8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val fixed = listOf("all" to "All", "unread" to "Unread", "personal" to "Personal", "groups" to "Groups", "channels" to "Channels", "bots" to "Bots", "archive" to "Archive")
                items(fixed) { (k, n) -> FolderChip(n, MainState.folder == k, onLong = null) { MainState.folder = k } }
                items(LocalFolders.list.toList()) { f ->
                    FolderChip(f.icon + " " + f.name, MainState.folder == "f:" + f.id, onLong = { Nav.push(Route.Folders) }) { MainState.folder = "f:" + f.id }
                }
                item { FolderChip("＋", false, onLong = null) { Nav.push(Route.Folders) } }
            }
        }

        // ---- list
        PullToRefreshBox(
            isRefreshing = refreshing,
            onRefresh = { refreshing = true; scope.launch { try { Tg.reloadChats() } catch (e: Exception) { }; delay(400); refreshing = false } },
            modifier = Modifier.weight(1f)
        ) {
            LazyColumn(Modifier.fillMaxSize(), state = MainState.listState) {
                if (S.debugOverlay.v) item {
                    Text("chats=${all.size} cache=${Tg.chatCache.size} users=${Tg.users.size} conn=$conn", color = c.sec, fontSize = 11.sp, modifier = Modifier.padding(8.dp))
                }
                if (S.smartArchive.v && MainState.folder == "all") {
                    val cutoff = (System.currentTimeMillis() / 1000 - 30 * 86400).toInt()
                    val idle = rows.filter { !it.pinned && it.lastDate in 1 until cutoff }
                    if (idle.isNotEmpty()) item {
                        Row(Modifier.fillMaxWidth().background(c.surface2).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${idle.size} chats idle for 30+ days", color = c.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            TextButton({ idle.forEach { Tg.archive(it.id, true) } }) { Text("Archive", color = c.accent) }
                        }
                    }
                }
                items(rows, key = { it.id }) { r ->
                    ChatRowItem(r, selecting)
                    Divider()
                }
                if (rows.isEmpty()) item {
                    Text("No chats here", color = c.sec, modifier = Modifier.fillMaxWidth().padding(40.dp), fontSize = 15.sp)
                }
            }
        }
    }

    if (pickContact) ContactPickDialog({ pickContact = false }) { uid -> pickContact = false; scope.launch { Tg.openPrivate(uid)?.let { Nav.openChat(it) } } }
}

@Composable
fun FolderChip(label: String, selected: Boolean, onLong: (() -> Unit)?, onClick: () -> Unit) {
    val c = Nova.c
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) c.accent else c.surface2)
            .springClick(onLong, onClick).padding(horizontal = 14.dp, vertical = 7.dp)
    ) { Text(label, color = if (selected) Color.White else c.text, fontSize = 14.sp) }
}

@Composable
fun ChatRowItem(r: ChatRow, selecting: Boolean) {
    val c = Nova.c
    val selected = r.id in MainState.sel

    val content: @Composable () -> Unit = {
        val padV = when (S.density.v) { "Compact" -> 6.dp; "Roomy" -> 14.dp; else -> 10.dp }
        Row(
            Modifier.fillMaxWidth().background(if (selected) c.accent.copy(alpha = 0.18f) else c.bg)
                .springClick(onLong = { if (r.id !in MainState.sel) MainState.sel.add(r.id) }) {
                    if (selecting) { if (selected) MainState.sel.remove(r.id) else MainState.sel.add(r.id) } else Nav.openChat(r.id)
                }
                .padding(horizontal = 12.dp, vertical = padV),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                Avatar(r.photoId, r.title, S.avatarSize.v.dp)
                if (selected) Box(Modifier.align(Alignment.BottomEnd).size(18.dp).clip(CircleShape).background(c.accent), contentAlignment = Alignment.Center) {
                    Text("✓", color = Color.White, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (r.muted) Icon(Icons.Filled.VolumeOff, null, tint = c.sec, modifier = Modifier.padding(start = 4.dp).size(14.dp))
                    Spacer(Modifier.weight(1f))
                    if (S.showTime.v) Text(fmtListTime(r.lastDate), color = c.sec, fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (S.showPreview.v) {
                        val hidden = S.privacyMode.v && !MainState.revealed
                        Text(
                            if (hidden) "• • •" else (if (r.lastOut) "You: " else "") + r.last,
                            color = c.sec, fontSize = 14.sp, maxLines = S.previewLines.v, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                    } else Spacer(Modifier.weight(1f))
                    if (r.pinned && r.unread == 0) Icon(Icons.Filled.PushPin, null, tint = c.sec, modifier = Modifier.size(15.dp))
                    if (r.unread > 0 || r.markedUnread) {
                        val badge = if (r.muted && S.mutedGrey.v) c.sec.copy(alpha = 0.6f) else c.accent
                        Box(Modifier.padding(start = 6.dp).clip(RoundedCornerShape(50)).background(badge).padding(horizontal = 7.dp, vertical = 1.dp)) {
                            Text(if (r.unread > 0) (if (r.unread > 999) "999+" else "${r.unread}") else "•", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }

    if (S.swipeActions.v && !selecting) {
        val state = rememberSwipeToDismissBoxState(confirmValueChange = { v ->
            when (v) {
                SwipeToDismissBoxValue.StartToEnd -> doAction(S.swipeRight.v, r)
                SwipeToDismissBoxValue.EndToStart -> doAction(S.swipeLeft.v, r)
                else -> {}
            }
            false
        })
        SwipeToDismissBox(
            state,
            backgroundContent = {
                val right = state.dismissDirection == SwipeToDismissBoxValue.StartToEnd
                Box(Modifier.fillMaxSize().background(c.accent).padding(horizontal = 20.dp), contentAlignment = if (right) Alignment.CenterStart else Alignment.CenterEnd) {
                    Text(actionLabel(if (right) S.swipeRight.v else S.swipeLeft.v, r), color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            },
            content = { content() }
        )
    } else content()
}

// ------------------------------------------------------------------ contacts

@Composable
fun ContactsTab() {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf<List<org.drinkless.tdlib.TdApi.User>>(emptyList()) }
    var q by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { users = Tg.contacts().sortedBy { (it.firstName + it.lastName).lowercase() }; loading = false }
    Column(Modifier.fillMaxSize()) {
        TopBar("Contacts", onBack = null)
        Box(Modifier.padding(12.dp)) { NField(q, { q = it }, "Search contacts") }
        val list = users.filter { q.isBlank() || (it.firstName + " " + it.lastName).contains(q, true) }
        LazyColumn(Modifier.weight(1f)) {
            items(list, key = { it.id }) { u ->
                Row(Modifier.fillMaxWidth().clickable { scope.launch { Tg.openPrivate(u.id)?.let { Nav.openChat(it) } } }.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(u.profilePhoto?.small?.id ?: 0, u.firstName, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text((u.firstName + " " + u.lastName).trim(), color = c.text, fontSize = 16.sp)
                        Text(Tg.statusText(u), color = if (Tg.statusText(u) == "online") c.accent else c.sec, fontSize = 13.sp)
                    }
                }
            }
            if (!loading && list.isEmpty()) item { Text("No contacts", color = c.sec, modifier = Modifier.padding(32.dp)) }
        }
    }
}

@Composable
fun ContactPickDialog(onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    val c = Nova.c
    var users by remember { mutableStateOf<List<org.drinkless.tdlib.TdApi.User>>(emptyList()) }
    LaunchedEffect(Unit) { users = Tg.contacts().sortedBy { (it.firstName + it.lastName).lowercase() } }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = c.surface2,
        title = { Text("Pick a contact", color = c.text) },
        text = {
            LazyColumn(Modifier.height(360.dp)) {
                items(users, key = { it.id }) { u ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(u.id) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u.profilePhoto?.small?.id ?: 0, u.firstName, 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Text((u.firstName + " " + u.lastName).trim(), color = c.text, fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close", color = c.accent) } }
    )
}
