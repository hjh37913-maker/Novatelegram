package app.nova

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableLongStateOf
import androidx.fragment.app.FragmentActivity
import app.nova.data.S
import app.nova.tg.Tg
import app.nova.ui.Lock
import app.nova.ui.NovaTheme
import app.nova.ui.Root

class MainActivity : FragmentActivity() {
    companion object { val pendingChat = mutableLongStateOf(0L) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handle(intent)
        Lock.init()
        setContent { NovaTheme { Root(this) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val id = i?.getLongExtra("chat", 0L) ?: 0L
        if (id != 0L) pendingChat.longValue = id
    }

    override fun onStart() {
        super.onStart()
        Tg.foreground = true
        Lock.onStart()
        if (S.sp.getBoolean("started_once", false)) Tg.setOnline(true)
    }

    override fun onStop() {
        super.onStop()
        Tg.foreground = false
        Lock.onStop()
        Tg.setOnline(false)
    }

    fun applySecure(on: Boolean) {
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
}
