package app.nova.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import app.nova.BuildConfig
import app.nova.MainActivity
import app.nova.data.S
import app.nova.service.KeepAliveService
import app.nova.tg.Tg
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

fun creds(): Pair<Int, String>? {
    val id = S.str("api_id").toIntOrNull() ?: BuildConfig.TG_API_ID
    val h = S.str("api_hash").ifBlank { BuildConfig.TG_API_HASH }
    return if (id > 0 && h.isNotBlank()) id to h else null
}

@Composable
fun Root(activity: MainActivity) {
    val ctx = LocalContext.current
    val c = Nova.c
    val auth by Tg.auth.collectAsState()
    var apiOk by remember { mutableStateOf(creds() != null) }
    var welcomed by remember { mutableStateOf(S.flag("welcomed")) }
    var styled by remember { mutableStateOf(S.flag("styled")) }
    val ready = auth is TdApi.AuthorizationStateReady

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(apiOk) { creds()?.let { if (apiOk) Tg.start(ctx.applicationContext, it.first, it.second) } }
    LaunchedEffect(S.screenshotProt.v) { activity.applySecure(S.screenshotProt.v) }
    LaunchedEffect(ready) {
        if (ready) {
            if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            if (S.autoClean.v) try { Tg.optimize(S.autoCleanDays.v) } catch (e: Exception) { }
        }
    }
    LaunchedEffect(S.keepAlive.v, ready) {
        try {
            val i = Intent(ctx, KeepAliveService::class.java)
            if (S.keepAlive.v && ready) ctx.startForegroundService(i) else ctx.stopService(i)
        } catch (e: Exception) { }
    }
    LaunchedEffect(MainActivity.pendingChat.longValue, ready, styled) {
        val id = MainActivity.pendingChat.longValue
        if (id != 0L && ready && styled) { Nav.openChat(id); MainActivity.pendingChat.longValue = 0L }
    }
    val view = LocalView.current
    LaunchedEffect(c.light) {
        val ic = WindowCompat.getInsetsController(activity.window, view)
        ic.isAppearanceLightStatusBars = c.light
        ic.isAppearanceLightNavigationBars = c.light
    }

    Box(Modifier.fillMaxSize().background(c.bg)) {
        Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            when {
                !welcomed -> WelcomeScreen { S.setFlag("welcomed", true); welcomed = true }
                !apiOk -> ApiSetupScreen { id, hash ->
                    S.setStr("api_id", id.toString()); S.setStr("api_hash", hash); apiOk = true
                }
                auth == null -> Splash()
                !ready -> LoginScreen(auth!!)
                !styled -> StyleScreen { S.setFlag("styled", true); styled = true }
                else -> MainHost()
            }
        }
        if (Lock.locked) LockScreen(activity)
    }
}

@Composable
fun Splash() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Nova", color = Nova.c.text, fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            CircularProgressIndicator(color = Nova.c.accent, modifier = Modifier.size(28.dp), strokeWidth = 2.dp)
        }
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Nova.c.accent, contentColor = Color.White, disabledContainerColor = Nova.c.surface2)
    ) { Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun NField(value: String, onChange: (String) -> Unit, label: String, kb: KeyboardType = KeyboardType.Text, password: Boolean = false) {
    val c = Nova.c
    OutlinedTextField(
        value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = kb),
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = c.text, unfocusedTextColor = c.text, focusedBorderColor = c.accent, unfocusedBorderColor = c.border,
            focusedLabelColor = c.accent, unfocusedLabelColor = c.sec, cursorColor = c.accent
        )
    )
}

@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    val c = Nova.c
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center) {
        Text("Nova", color = c.accent, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))
        Text("Your Telegram.\nYour interface.", color = c.text, fontSize = 40.sp, fontWeight = FontWeight.Bold, lineHeight = 46.sp)
        Spacer(Modifier.height(16.dp))
        Text("An unofficial Telegram client built on TDLib.", color = c.sec, fontSize = 16.sp)
        Spacer(Modifier.height(40.dp))
        PrimaryButton("Continue", onClick = onContinue)
    }
}

@Composable
fun ApiSetupScreen(onDone: (Int, String) -> Unit) {
    val c = Nova.c
    var id by remember { mutableStateOf("") }
    var hash by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Telegram API keys", color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Every Telegram client needs its own api_id and api_hash. Get yours (free, 1 minute) at my.telegram.org → API development tools. They are stored only on this device.",
            color = c.sec, fontSize = 14.sp
        )
        Spacer(Modifier.height(20.dp))
        NField(id, { id = it.filter(Char::isDigit) }, "api_id", KeyboardType.Number)
        Spacer(Modifier.height(12.dp))
        NField(hash, { hash = it.trim() }, "api_hash")
        Spacer(Modifier.height(24.dp))
        PrimaryButton("Save and continue", enabled = id.toIntOrNull() != null && hash.length >= 16) { onDone(id.toInt(), hash) }
    }
}

@Composable
fun LoginScreen(state: TdApi.AuthorizationState) {
    val c = Nova.c
    val scope = rememberCoroutineScope()
    var text by remember(state.javaClass) { mutableStateOf("") }
    var busy by remember(state.javaClass) { mutableStateOf(false) }
    var error by remember(state.javaClass) { mutableStateOf("") }

    fun run(block: suspend () -> Unit) {
        busy = true; error = ""
        scope.launch {
            try { block() } catch (e: Exception) { error = e.message ?: "Error" }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center) {
        when (state) {
            is TdApi.AuthorizationStateWaitPhoneNumber -> {
                Text("Your phone number", color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Use international format, e.g. +380501234567", color = c.sec, fontSize = 14.sp)
                Spacer(Modifier.height(20.dp))
                NField(text, { text = it.filter { ch -> ch.isDigit() || ch == '+' } }, "Phone", KeyboardType.Phone)
                Spacer(Modifier.height(20.dp))
                PrimaryButton("Send code", enabled = !busy && text.length >= 7) { run { Tg.sendPhone(text) } }
            }
            is TdApi.AuthorizationStateWaitCode -> {
                Text("Enter the code", color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Telegram sent a login code to your other device or by SMS.", color = c.sec, fontSize = 14.sp)
                Spacer(Modifier.height(20.dp))
                NField(text, { text = it.filter(Char::isDigit) }, "Code", KeyboardType.Number)
                Spacer(Modifier.height(20.dp))
                PrimaryButton("Verify", enabled = !busy && text.length >= 4) { run { Tg.sendCode(text) } }
            }
            is TdApi.AuthorizationStateWaitPassword -> {
                Text("Two-step verification", color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (state.passwordHint.isNotEmpty()) Text("Hint: ${state.passwordHint}", color = c.sec, fontSize = 14.sp)
                Spacer(Modifier.height(20.dp))
                NField(text, { text = it }, "Password", KeyboardType.Password, password = true)
                Spacer(Modifier.height(20.dp))
                PrimaryButton("Continue", enabled = !busy && text.isNotEmpty()) { run { Tg.sendPassword(text) } }
            }
            is TdApi.AuthorizationStateWaitRegistration -> {
                Text("Number not registered", color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Create the account in the official Telegram app first, then come back.", color = c.sec, fontSize = 14.sp)
            }
            is TdApi.AuthorizationStateLoggingOut, is TdApi.AuthorizationStateClosing, is TdApi.AuthorizationStateClosed -> Splash()
            is TdApi.AuthorizationStateWaitTdlibParameters -> Splash()
            else -> {
                Text("Unsupported login step", color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(state.javaClass.simpleName + "\nThis client does not support this step yet (e-mail login, QR, etc.).", color = c.sec, fontSize = 14.sp)
            }
        }
        if (error.isNotEmpty()) { Spacer(Modifier.height(12.dp)); Text(error, color = Color(0xFFFF5C5C), fontSize = 14.sp) }
        if (busy) { Spacer(Modifier.height(16.dp)); CircularProgressIndicator(color = c.accent, modifier = Modifier.size(24.dp), strokeWidth = 2.dp) }
    }
}

// ------------------------------------------------------------------ style presets

fun applyStyle(name: String) {
    when (name) {
        "Minimal" -> {
            S.themeMode.set("Dark"); S.bubbleStyle.set("Flat"); S.bubbleRadius.set(10); S.density.set("Compact")
            S.avatarSize.set(44); S.msgSpacing.set(2)
        }
        "Classic" -> {
            S.themeMode.set("Classic"); S.bubbleStyle.set("Filled"); S.bubbleRadius.set(14); S.density.set("Normal"); S.avatarSize.set(52)
        }
        "Dark" -> { S.themeMode.set("Dark"); S.bubbleStyle.set("Filled"); S.bubbleRadius.set(18); S.density.set("Normal") }
        "AMOLED" -> { S.themeMode.set("AMOLED"); S.bubbleStyle.set("Filled"); S.bubbleRadius.set(18); S.density.set("Normal") }
        "Custom" -> { copyPaletteToCustom("Dark", true); S.themeMode.set("Custom") }
    }
}

@Composable
fun StyleScreen(onDone: () -> Unit) {
    val c = Nova.c
    var picked by remember { mutableStateOf(S.themeMode.v) }
    val styles = listOf("Minimal", "Classic", "Dark", "AMOLED", "Custom")
    val colors = mapOf(
        "Minimal" to listOf(Color(0xFF08090D), Color(0xFF171920), Color(0xFF2C5CB8)),
        "Classic" to listOf(Color(0xFF0E1621), Color(0xFF182533), Color(0xFF3F6FA5)),
        "Dark" to listOf(Color(0xFF08090D), Color(0xFF111318), Color(0xFF4C8DFF)),
        "AMOLED" to listOf(Color.Black, Color(0xFF131313), Color(0xFF4C8DFF)),
        "Custom" to listOf(Color(0xFF1B1030), Color(0xFF2A1A4A), Color(0xFFB57BFF))
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Text("Choose your style", color = c.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("You can change everything later in Settings.", color = c.sec, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
        styles.forEach { s ->
            val cols = colors.getValue(s)
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(c.surface)
                    .border(if (picked == s) 2.dp else 1.dp, if (picked == s) c.accent else c.border, RoundedCornerShape(16.dp))
                    .springClick { picked = s; applyStyle(s) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(Modifier.size(width = 64.dp, height = 40.dp).clip(RoundedCornerShape(10.dp)).background(cols[0]).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(Modifier.weight(1f).fillMaxSize().clip(RoundedCornerShape(4.dp)).background(cols[1]))
                    Box(Modifier.weight(1f).fillMaxSize().clip(RoundedCornerShape(4.dp)).background(cols[2]))
                }
                Spacer(Modifier.size(16.dp))
                Text(s, color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.height(24.dp))
        PrimaryButton("Done") { onDone(); if (picked == "Custom") Nav.push(Route.ThemeEditor) }
    }
}

// ------------------------------------------------------------------ navigation host

@Composable
fun MainHost() {
    val c = Nova.c
    val top = Nav.stack.last()
    BackHandler(Nav.stack.size > 1) { Nav.pop() }
    AnimatedContent(
        targetState = top,
        transitionSpec = {
            val fwd = Nav.forward
            val d = Motion.ms(260)
            if (Motion.reduced) EnterTransition.None togetherWith ExitTransition.None
            else if (targetState is Route.Profile && fwd) (fadeIn(tween(d)) + scaleIn(tween(d), initialScale = 0.88f)) togetherWith fadeOut(tween(d / 2))
            else if (fwd) (slideInHorizontally(tween(d)) { it / 4 } + fadeIn(tween(d))) togetherWith (slideOutHorizontally(tween(d)) { -it / 6 } + fadeOut(tween(d)))
            else (slideInHorizontally(tween(d)) { -it / 6 } + fadeIn(tween(d))) togetherWith (slideOutHorizontally(tween(d)) { it / 4 } + fadeOut(tween(d)))
        },
        label = "nav"
    ) { r ->
        Box(Modifier.fillMaxSize().background(c.bg).edgeBack()) {
            when (r) {
                is Route.Main -> MainScreen()
                is Route.Chat -> ChatScreen(r)
                is Route.Profile -> ProfileScreen(r)
                is Route.EditProfile -> EditProfileScreen()
                is Route.Search -> SearchScreen(r.chatId)
                is Route.Settings -> SettingsScreen(r.section)
                is Route.ThemeEditor -> ThemeEditorScreen()
                is Route.BannerEditor -> BannerEditorScreen(r.userId)
                is Route.Security -> SecurityScreen()
                is Route.About -> AboutScreen()
                is Route.Folders -> FoldersScreen()
                is Route.Downloads -> DownloadsScreen()
                is Route.Cache -> CacheScreen()
                is Route.Media -> MediaViewerScreen(r)
                is Route.Forward -> ForwardScreen(r)
            }
        }
    }
}
